# Pendência independente — History API durante navegação suspensa

**Estado:** registrada localmente para acompanhamento separado; minuta pronta
para issue própria. Nenhuma issue remota foi criada. Identificador definitivo,
prioridade e responsável ainda não definidos. Relaciona-se ao PR #47, mas não é
requisito adicional da correção da issue #45.

**Decisão do proprietário:** opção A, sem contorno de `pushState`/`replaceState`
durante navegação suspensa; sem mudança de código ou dependências nesta avaliação.

## Fatos comprovados

Em 06/11/2026 foi executado o mesmo teste com asserções reais contra cópias
**integrais** dos commits:

- Master: `0d69203e5553578c252714baed7d1e924ba685dd`;
- PR #47: `3736977a1dad19f2a4635fac8c789fe1f0c2ccf4`.

Node 24.22.2, Next 16.4.2, React 19.2.8 e Playwright 1.62.1; lock e `.nvmrc`
idênticos. Builds novos e servidores próprios, sem reutilização de servidor.

| Motor    | Sem mutação durante suspensão, master e head | `pushState(null, '', '?q=2')`, ambos                                                                | `replaceState(null, '', '?q=2')`, ambos |
| -------- | -------------------------------------------- | --------------------------------------------------------------------------------------------------- | --------------------------------------- |
| Chromium | Passa; skip/Tab cancelam Sobre               | Falha: nova navegação de documento para a 404 com query                                             | Mesma falha                             |
| Firefox  | Passa                                        | Falha: documentos para a 404 com query e Sobre; URL/H1 passam a Sobre antes de liberar os segmentos | Mesma falha                             |
| WebKit   | Passa                                        | Falha: documentos para a 404 com query e Sobre; URL/H1 passam a Sobre antes de liberar os segmentos | Mesma falha                             |

Cada versão teve **3 controles aprovados e 6 falhas**, sem retries, skips ou
inversão da expectativa. São observações de uma execução por método/motor/versão,
não uma estimativa estatística de frequência. O Chromium pode terminar com
URL/foco aparentemente corretos depois do recarregamento: verificar só o estado
final não detecta a navegação extra.

A variante v1, também preservada, não tinha asserção de ausência de nova navegação
de documento e passou no Chromium. A v2 adiciona essa verificação, mantendo as
asserções de URL/H1/foco; ambas as versões e seus resultados foram conservados.

Evidência: [comparação por caso](evidencias/diagnostic-comparison.json), relatórios
`diagnostic-v2-master.json` e `diagnostic-v2-head.json`, logs, anexos e traces no
[inventário](evidencias/README.md). As sondas hospedadas históricas também registram
o desvio Firefox/WebKit e o recarregamento Chromium no mesmo deployment do PR.

**Conclusão permitida:** o patch do PR #47 não é condição necessária para este
comportamento; ele também ocorre na master integral. A classificação como
preexistente é sustentada pela comparação, sem depender apenas de remover
FragmentHistory de uma candidata modificada.

## Hipóteses e limites

- A interação da History API integrada ao App Router com árvore de Sobre já
  adotada e commit suspenso pode disparar resolução da 404, fallback MPA e
  competição entre documentos. A sequência é compatível com as observações;
  a cadeia causal interna completa não foi demonstrada.
- Não atribuir definitivamente a Next, React ou um motor específico. Não há
  reprodução mínima fora do aplicativo nem issue upstream confirmada aqui.
- Os resultados não demonstram defeito de queries já confirmadas, que passaram
  nos controles da issue #45. Também não explicam automaticamente outras falhas
  de Voltar/Avançar ou de `:target` sem a mutação concorrente.
- Query `?q=2` e estado `null` foram os casos comparados com asserções. Hash puro,
  estados próprios, outras rotas/latências e builds sem FragmentHistory inteiro
  não foram reavaliados nesta rodada. Não generalizar para todas as chamadas.

## Reprodução controlada

1. Servir build de produção da versão identificada, em servidor exclusivo.
2. Em `/rota-inexistente`, permitir a resposta de prefetch `/_tree` de `/sobre`,
   mas reter os demais segmentos de Sobre. Confirmar árvore recebida e pelo
   menos um segmento retido; não basta introduzir um timeout sem essas guardas.
3. Acionar Sobre e aguardar 300 ms. Confirmar URL da 404 e H1 de página não
   encontrada: o commit está suspenso, com a 404 ainda apresentada.
4. Executar `history.pushState(null, '', '?q=2')` ou
   `history.replaceState(null, '', '?q=2')`; aguardar 700 ms, ainda sem liberar
   os segmentos retidos. Registrar documentos, URL, H1, foco e tamanho do histórico.
5. Exigir permanência em `/rota-inexistente?q=2`, H1 da 404 e apenas o documento
   inicial. A reprodução falha nessa etapa nos três motores, pelos motivos acima.
6. No controle sem mutação, acionar skip, pressionar Tab, liberar os segmentos e
   confirmar permanência na 404 e foco no link de retorno. Os controles passaram.

O harness permite requisições de documento para Sobre; portanto uma eventual
navegação MPA não fica artificialmente presa pelo bloqueio dos segmentos.

## Preservação fora dos gates

O teste está preservado como `pending-history.spec.ts.txt`, junto com a configuração
diagnóstica, em `evidencias/`. Copiá-los para `diagnostics-v2/` de uma cópia isolada
com dependências já disponíveis reproduz a execução. A configuração explícita
coleta somente esse diretório; o teste não foi adicionado a `tests/e2e`, CI, lint,
build ou gates do PR. Nenhuma configuração obrigatória foi modificada.

As execuções diagnósticas terminaram com saída **1**. Não foi usado `test.fail`,
`skip`, retry ou captura de erro para produzir aprovação. A falha é o resultado
esperado da investigação, mas continua sendo uma falha real do comportamento
assertado, não um teste verde.

## Critérios de aceite propostos para o acompanhamento

Estes critérios regem a investigação futura; não alteram a spec da issue #45.

- [x] Distinguir fatos, hipóteses, limites e versão de reprodução.
- [x] Comparar master integral e candidata, com controle sem mutação e três motores.
- [x] Conservar teste, falhas, logs e identidade fora dos gates obrigatórios.
- [ ] Definir o contrato esperado para History API durante uma transição pendente,
      medir o impacto para o visitante e decidir prioridade e responsável.
- [ ] Isolar a causa, preferencialmente com reprodução mínima, e avaliar tratamento
      upstream ou local em trabalho explicitamente autorizado.
- [ ] Se houver correção futura, exigir teste que falhe nas versões afetadas e
      passe sem navegação extra ou perda de coerência; cobrir ambos os métodos e
      preservar foco/teclado, F1, A1 e PROD-001 nos três motores.
- [ ] Registrar decisão de encerramento ou aceite do risco com evidência, sem
      converter esta reprodução em aprovação artificial dos gates de outro PR.

Impacto residual conhecido: recarregamento pode perder contexto/foco; em
Firefox/WebKit a ação deixa de permanecer na 404 e passa a Sobre antes da liberação
dos segmentos. Opção A aceita o acompanhamento separado, não declara o defeito
corrigido ou sem impacto.
