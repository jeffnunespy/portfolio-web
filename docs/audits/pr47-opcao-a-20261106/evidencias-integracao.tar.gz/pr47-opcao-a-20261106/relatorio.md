> **Estado vigente:** ver [encerramento técnico dirigido](encerramento-tecnico.md).
> As decisões abaixo são históricas; a triagem B/skip está encerrada, sem correção declarada.

# PR #47 — reavaliação pela opção A

**Atualização dirigida:** a [continuação A/B/C](#continuação-dirigida--grupos-abc)
ao fim deste mesmo relatório registra a classificação atual e o diff de testes.
O registro da primeira rodada abaixo foi preservado. Homologação continua **NO-GO**.
O [fechamento dirigido de B/skip](#fechamento-dirigido-de-bskip) registra a aplicação
local do diff e o limite causal remanescente, sem reabrir A/C.

**Parecer: NO-GO para homologação.** A limitação de History API foi separada como
comportamento preexistente. O bloqueio atual vem das falhas de validação de
histórico/A1 e da avaliação com leitor de tela ainda ausente, não daquela limitação.
Nenhum defeito novo na correção foi causalmente demonstrado por esta revisão.

## Escopo e identidade

- Issue de aceite: [#45](https://github.com/jeffnunespy/portfolio-web/issues/45);
  PR: [#47](https://github.com/jeffnunespy/portfolio-web/pull/47).
- Head: `3736977a1dad19f2a4635fac8c789fe1f0c2ccf4`.
- Base e master remota, reconferida nesta sessão:
  `0d69203e5553578c252714baed7d1e924ba685dd`.
- Preview imutável: <https://portfolio-82qy5hshv-jeff-0a6e.vercel.app>;
  deployment `dpl_EnWNDNXMztJLLTJwSWC4vntPfq2d`, Ready, ambiente Preview
  confirmado por `vercel inspect`; API e HTML reconfirmaram SHA e identidade.
- BUILD_ID hospedado: `i_qv7YR4GKIqrXi-ZwgRu`; canonical/origem do build:
  `https://portfolio-82qy5hshv-jeff-0a6e.vercel.app`.
- Cópias locais integrais extraídas por `git archive`, em
  `/tmp/pr47-option-a-20261106/head` e `/tmp/pr47-option-a-20261106/master`.
  BUILD_IDs: `aS5XpKUEP1RM46HGOngAC` e `O1MlpWwF_WXhu51lx1hjb`.
  Origem local de build: `https://portfolio.example`.
- Node 24.22.2, Next 16.4.2, React 19.2.8, Playwright 1.62.1.
  `.nvmrc` e lockfile iguais entre base e head; hashes em
  [isolation.json](evidencias/isolation.json).

Risco 3 mantido. A opção A não autoriza contorno da History API, mudança dos
requisitos ou dispensa dos gates. Código original, testes rastreados, dependências,
CI e especificações não foram alterados. Não houve commit, push, mensagem remota,
merge, deploy ou criação de token de acesso.

## Critérios de aceite e resultado

| Critério                                                    | Resultado e alcance                                                                                                                                                                                                                                             |
| ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Skip → Tab sob janela de latência, sem perda tardia de foco | Direta, query direta e query alterada **antes** da transição passaram nos três motores, localmente e no Preview. O teste injeta atraso de 300 ms se houver RSC e exige zero RSC redundante; não afirma que uma resposta RSC atrasada foi recebida na candidata. |
| Teclado e foco visível                                      | Smoke hospedado passou em Chromium, Firefox e WebKit: skip visível, Enter → main, Tab → retorno, outline visível, Tab/Shift+Tab e recuperação por Enter para Projetos.                                                                                          |
| Cancelar Sobre com commit suspenso, preservando histórico   | Cenário positivo hospedado passou nos três motores; localmente falhou uma vez no Avançar em Chromium. Três tentativas isoladas subsequentes passaram sem alterações. A primeira falha permanece e a estabilidade não está demonstrada.                          |
| F1                                                          | Suíte local passou; evidência hospedada histórica de coerência URL/conteúdo foi recuperada. Quatro verificações hospedadas atuais no Chromium falharam em `:target`; não foram removidas nem classificadas automaticamente como R05 ou regressão do PR.         |
| A1                                                          | Local passou nos três motores. Preview atual: Chromium/Firefox passaram nos casos A1 exclusivos; WebKit falhou em duas variantes. Homologação completa ainda não aprovada.                                                                                      |
| PROD-001                                                    | Cinco cenários por motor passaram localmente e no Preview, incluindo 404 e recuperação sem JS e fichas publicadas com HTTP 200.                                                                                                                                 |
| Controle negativo, gates e revisão                          | Controle negativo renovado na master integral: 3/3 falhas de foco Chromium, sem a correção; teste idêntico preservado. CI do candidato confirmado verde; revisão independente sem bloqueador causal no patch, mas exige NO-GO diante dos resultados atuais.     |
| Avaliar com leitor de tela e decidir aceite/correção (#45)  | Nenhum registro de leitor real encontrado. Axe, teclado e revisão semântica não substituem esta avaliação. Sem dispensa expressa; requisito permanece pendente. T055 não foi encerrada.                                                                         |

Query confirmada antes de iniciar a navegação faz parte do aceite positivo. Mutar
`pushState`/`replaceState` **durante** o commit suspenso é a
[pendência independente](pendencia-history-api-suspensa.md). Não se converte uma
falha de F1/A1 sem essa mutação em manifestação da pendência separada.

## Resultados por navegador

Todas as rodadas novas tiveram zero retries e zero testes pulados.

| Rodada                                                          | Chromium           | Firefox            | WebKit             |
| --------------------------------------------------------------- | ------------------ | ------------------ | ------------------ |
| Local dirigido: foco, histórico, projeto 404                    | 26/27; 1 falha     | 27/27              | 27/27              |
| Preview dirigido, mesmos testes com padrão de chunks hospedados | 23/27; 4 falhas    | 27/27              | 25/27; 2 falhas    |
| Teclado/foco visível no Preview, complemento                    | 1/1                | 1/1                | 1/1                |
| Repetição isolada do teste local que falhou                     | 3/3                | Não repetido       | Não repetido       |
| Diagnóstico independente no head: sem mutação / push / replace  | 1 passa / 2 falham | 1 passa / 2 falham | 1 passa / 2 falham |
| Mesmo diagnóstico na master integral                            | 1 passa / 2 falham | 1 passa / 2 falham | 1 passa / 2 falham |

Controle negativo adicional: o teste direto de foco da candidata foi copiado sem alterações para fora dos gates da master integral e falhou 3/3 vezes em Chromium (`negative-control.json`), por perda de foco no link de retorno. Não foi invertida a expectativa.

As três repetições aprovadas não substituem a rodada local de 80/81. O campo
`flaky: 0` do JSON descreve aquela execução sem retries; não invalida a
intermitência constatada entre execuções.

Falhas preservadas:

1. Local Chromium, `foco-404-latencia.spec.ts:119`: após Voltar, Avançar ficou em
   `/rota-inexistente`, esperado `#main-content`. O foco inicial e o cancelamento
   já haviam sido aprovados. Trace preservado; causa ainda não determinada.
2. Preview Chromium, `historico-fragmentos.spec.ts:46`: `:target` ausente nos
   cenários A1/F4 Ler descrição, âncora da home, índice da ficha e mesmo fragmento.
   As comparações anteriores de URL, título, H1 e navegação passaram; a orientação
   por fragmento não foi aprovada nesses casos.
3. Preview WebKit, A1 via skip: retorno esperado à 404 terminou com H1 `Projetos`.
4. Preview WebKit, A1 via `location.hash`: estado do histórico permaneceu nulo na
   verificação que exige estado restaurado não nulo (`:255`).

Os testes hospedados preservam todas as asserções; somente a interceptação dos
chunks foi adaptada para admitir o diretório `immutable`. Não há evidência nesta
sessão que autorize atribuir as falhas acima ao patch, ao harness ou ao navegador.
Elas bloqueiam a conclusão do gate até esclarecimento dirigido.

## Evidências reaproveitadas

O diretório antigo `/tmp/issue45-evidence` e o de homologação
`/tmp/aud03-preview47` não existem nesta sessão. Foram recuperadas **saídas reais
de ferramentas**, e não conclusões narrativas, dos registros persistentes da
sessão anterior, com fonte, linha, data e hash:
[registro recuperado](evidencias/recovered-hosted-evidence.json).

O mesmo SHA, BUILD_ID e origem hospedados foram reconferidos. Reaproveitados os
PASS individuais de foco/queries confirmadas, F1 válido/pré-hidratação, A1,
PROD-001, axe e overflow em 390/1280 nos três motores. Não foi repetida a auditoria
completa. Screenshots, traces e payloads completos dos PASS antigos não foram
recuperados; esse limite está registrado. Falhas antigas, crashes Firefox e
calibração HTML/RSC inválida continuam no registro. O exit 0 das sondas antigas
não representa aprovação: elas capturavam FAIL por caso sem mudar a saída global.

CI reutilizado: [run 42144767147](https://github.com/jeffnunespy/portfolio-web/actions/runs/42144767147),
job `quality` aprovado. O Actions testou o merge sintético
`d58c17dd4d61454e7ea84178db09a38ac73fc0f7`, ligado ao head/base acima,
BUILD_ID `Wqp5gvibdgzgoJRY4warh`: formato, lint, tipos, 122 unitários, build,
auditoria de produção, 206 E2E funcionais e 27 a11y. Logs não registram retries ou
flaky. O CI cobre Chromium e não substitui a homologação hospedada dos três motores.

## Segurança operacional e preservação

Antes das escritas foram conferidos `pwd -P`, `realpath`, Git, diretórios e
symlinks. As cópias são integrais e as dependências foram copiadas fisicamente,
sem `npm ci`, instalação ou link para `node_modules` do ambiente original.
Build inicial sem rede falhou ao obter fontes; builds isolados com rede passaram.
Primeiro início de servidor sob sandbox falhou; rodadas efetivas usaram permissão
de portas/navegadores. Todos os logs, inclusive tentativas malsucedidas, foram mantidos.

Preview protegido: utilizado acesso já existente, somente consultas; credenciais
ficaram em memória. Traces hospedados foram desativados para não gravar headers
de acesso; falhas, snapshots e JSONs foram conservados. Verificação de valores de
credenciais nos artefatos, inclusive ZIPs, não encontrou correspondências.
Artefatos consolidados em [evidencias/](evidencias/README.md); originais em
`/tmp/pr47-option-a-20261106` preservados. Alterações preexistentes do workspace
e diagnósticos não rastreados do checkout do PR foram preservados.

## Riscos residuais e condições para GO

- History API suspensa: impacto e reprodução na pendência independente, aceita
  para acompanhamento separado pela decisão do proprietário. Não implementado contorno.
- F1/A1 e estabilidade: esclarecer as sete falhas da rodada atual e demonstrar os
  requisitos afetados no mesmo head, com sincronização justificada e sem afrouxar
  asserções. Uma repetição positiva isolada não basta para apagar a falha original.
- Leitor de tela real: avaliar os fluxos da issue #45 e registrar resultado e
  decisão; T055 geral permanece aberta. Nenhuma inspeção humana foi fabricada.
- A restauração depende de estado opaco e tratamento de `popstate` do App Router;
  exige revalidação quando Next mudar. R05 continua independente, sem extensão
  automática para explicar falhas novas no Chromium.

Não é possível confirmar integralmente F1/A1 e a estabilidade nos três motores
com estas evidências. **NO-GO** até sanar as lacunas de homologação e de avaliação
da issue #45. A separação da limitação preexistente permanece válida. Autorização
de merge/deploy e verificação pós-merge não fazem parte desta entrega.

## Continuação dirigida — grupos A/B/C

Mesmo head `3736977` e master integral `0d69203`, reconfirmados no GitHub.
Nenhuma regressão funcional do PR foi causalmente demonstrada. Isso não equivale
a aprovação do gate de homologação. History API durante navegação suspensa não
foi reaberta; R05 e T055 permanecem abertas.

### Comparação e causas

| Falha                                              | Causa identificada                                                                                                                                                                                                                             | Existe na master?                                                                                                             | Regressão do PR?                                                                     | Correção necessária?                                                                                                     |
| -------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------ |
| A — quatro `:target` Chromium hospedado            | URL, título, H1 e navegação corretos, mas `:target` ausente no retorno: esperados `contexto`, `projects-title`, `limitacoes`, `projects-title`. A orientação não foi aprovada; não é mero timeout de uma UI correta.                           | Sim: quatro falhas idênticas no deployment da master. Nos builds locais, quatro passam nas duas versões.                      | Não, nos quatro casos comparados.                                                    | Acompanhamento da orientação hospedada e decisão sobre o risco; não remover a asserção para obter verde.                 |
| B — WebKit `location.hash`                         | `history.state !== null` era exigido depois de conferir somente hidratação do Header. O listener ainda pode não estar pronto; em uma falha observada URL, 404, foco e alvo estavam corretos com estado nulo.                                   | A janela existe; a master espera estado nulo nessa fase. Comparações funcionais usam as expectativas próprias de cada versão. | Inadequação na sincronização do teste alterado; regressão funcional não demonstrada. | Aguardar o gerenciador nos cenários hidratados, mantendo a expectativa e os controles pré-hidratação.                    |
| B — WebKit skip, retorno termina com H1 `Projetos` | Falha funcional observada. Listener tardio reproduz o mesmo sintoma nas duas versões; navegação ainda não estabilizada também é uma precondição insuficiente do teste. Causa exclusiva do incidente original sem trace continua indeterminada. | Mesmo sintoma em controle com listener atrasado; isso não prova identidade causal do incidente original.                      | Não demonstrada; tampouco descartada definitivamente para esse incidente.            | Sincronização de prontidão e de navegação; conservar a lacuna de homologação. Não há base para alterar código funcional. |
| C — Chromium local, Avançar perde `#main-content`  | Corrida real durante hidratação da nova 404: o Next captura a URL inicial; Avançar muda o fragmento antes do commit, e `replaceState` posterior o remove antes do listener. O teste novo não sincronizava essa fase.                           | Sim, reprodução causal na master integral e no head.                                                                          | Defeito funcional preexistente; teste novo expõe a janela e fica instável.           | Sincronizar o teste de navegação hidratada; acompanhar separadamente a perda real de fragmento antes da hidratação.      |

A comparação hospedada usou somente deployments existentes: candidata
`dpl_EnWNDNXMztJLLTJwSWC4vntPfq2d`, BUILD_ID `i_qv7YR4GKIqrXi-ZwgRu`, e master
`dpl_4WJfqRd7J3fKF3c6DGWBntt5ygv5`, BUILD_ID `I1fbqvPwXnArbe8gKIxl5`, em
`https://portfolio-6gtoi26xt-jeff-0a6e.vercel.app`. SHA pela API e BUILD_ID pelo
HTML reconfirmados em [served-identities.json](evidencias/triagem-abc/served-identities.json).
Production foi apenas consultada; não houve deploy.

Para A, uma sonda de identidade do DOM constatou o alvo original desconectado
ao sair e um novo nó no retorno, nas duas versões hospedadas. A recriação do nó
sustenta a explicação para a associação nativa perdida, sem provar todos os
detalhes internos do Chromium. Nesse exemplo, rolagem voltou ao ponto correto,
mas foco ficou em BODY e `:target` ausente; outros snapshots têm rolagem zero.
Não generalizar o sucesso de rolagem desse exemplo aos quatro cenários.

Para C, o controle reteve o agendamento da hidratação via MessageChannel na
segunda carga, sem mudar o código da aplicação. No head: `popstate` com hash
aos 166,9 ms, `replaceState` sem hash aos 176,1 ms, listener aos 178,7 ms.
Na master: 160,1 → 170,5 → 171,6 ms. Mesma expectativa final falha nas duas;
liberar a hidratação antes de Avançar faz ambas passarem. Reter chunks antes da
inicialização não reproduziu a falha: é uma janela diferente, preservada como
controle, não uma repetição para apagar o erro. O trace original também registra
Avançar chegando ao hash e perdendo-o logo depois.

Para B, os dois fluxos completos sincronizados passaram na master e no head,
localmente e hospedados, com suas respectivas expectativas. O controle com
listener artificialmente tardio deixou Projetos nas duas versões. O controle
positivo sintético da master teve erro do harness durante uma recarga; não
conta como falha funcional nem como aprovação. O incidente original de skip
não ganhou uma causa exclusiva por inferência desses controles.

### Proposta local e validação

[Diff completo de testes](evidencias/triagem-abc/proposta-sincronizacao.diff),
preparado em `/tmp/pr47-triage-candidate-20261106`: observar inscrições e remoções
do listener de captura sem atrasá-las; aguardar prontidão nos cenários hidratados;
antes do último Voltar, exigir URL Projetos e a estabilidade já verificada pelo
helper existente. Asserções de foco, histórico, RSC, erros, documento e `:target`
continuam presentes. Skip pré-hidratação continua anterior à liberação dos chunks.
Nenhum componente, dependência, CI ou arquivo da master foi modificado.

- Tipos, ESLint dos três arquivos e Prettier aprovados no diff final.
- Primeira proposta: **22/24 locais e 22/24 hospedados**. As falhas foram
  preservadas: erros de prefetch no WebKit local e retorno ficando em Projetos
  no Firefox hospedado. Não foram silenciadas nem usadas para abrir outra auditoria.
- A última correção acrescentou conferência de URL e estabilidade antes do
  Voltar. Revalidação somente dessa etapa: **3/3 WebKit locais e 6/6
  Firefox/WebKit hospedados**, sem retries ou pulos. Os demais fluxos, incluindo
  foco da #45 e C nos três motores, já haviam passado na primeira proposta.
  Não existe uma rodada integral verde do diff final nem CI desse patch não enviado.
- [Revisão independente dirigida](evidencias/triagem-abc/revisao-independente.txt):
  proposta aprovada tecnicamente no escopo verificado; homologação NO-GO.
  O observador depende do contrato atual: um único `popstate` com captura na app.
- Build reaproveitado porque aplicação, lockfile e `.nvmrc` são idênticos ao
  head; identidades, comandos e limites em
  [resumo.json](evidencias/triagem-abc/resumo.json) e
  [patch-identity.json](evidencias/triagem-abc/patch-identity.json).

Artefatos anteriores permanecem intactos. Novos JSONs, contextos, harnesses,
diffs e hashes estão em `evidencias/triagem-abc/`; originais continuam em `/tmp`.
Traces hospedados desativados; busca em memória não encontrou credenciais nos
artefatos. Erros de seleção inicial e deadlocks do harness são registrados no
resumo e não contam como regressões da aplicação.

### Decisão vigente

**NO-GO para homologação do PR #47.** Não há correção funcional de regressão
confirmada a exigir no componente. A e a falha funcional C podem seguir em
acompanhamentos próprios, com decisão formal sobre seu impacto; a preexistência
não dispensa automaticamente gates. Não estender R05 ao Chromium por suposição.

Continuam bloqueando a conclusão do gate: atribuição incompleta do incidente
B/skip; sincronização insuficiente dos testes no head remoto, cujo ajuste ainda
é apenas proposta local; avaliação da #45 com leitor de tela real e decisão
correspondente, sem dispensa expressa. Se o patch for autorizado e enviado,
ele precisará de CI no novo head e confirmação da evidência afetada.

Inspeções humanas de teclado/foco, zoom, leitor de tela e aparelho físico de
T055 continuam sujeitas à matriz geral; esta triagem não as executa nem encerra.
Não houve commit, push, comentário remoto, alteração do PR, merge ou deploy.

## Fechamento dirigido de B/skip

**Diff conferido e incorporado à candidata local** em
`/home/jeff/projetos/portfolio-pr47`, ainda no head `3736977`, sem commit ou push.
Os três arquivos são idênticos, por SHA256, à proposta revisada e validada:
`foco-404-latencia.spec.ts`, `historico-fragmentos.spec.ts` e
`helpers/fragment-history.ts`. Diagnósticos locais preexistentes foram preservados.
Nenhuma verificação funcional foi removida. Prontidão significa listener de
captura efetivamente instalado; URL Projetos e estabilidade são verificadas antes
de Voltar. A janela de 700 ms já existia e verifica ausência de novos documentos,
RSC e erros; o diff não introduz um atraso fixo para ignorar uma falha.

### O que os registros permitem afirmar

O incidente WebKit original só conservou a falha de asserção e snapshot final:
a URL da 404 satisfez a primeira condição, mas o navegador terminou em
`/projetos`, com H1 Projetos. Não há trace, identidade de documento por etapa,
requisições ou pilha dos eventos daquele incidente. Assim, não é possível
determinar qual navegação estava pendente, qual evento final a confirmou nem
se houve um commit que deveria ter sido cancelado.

Antes de novas execuções, esses registros e o caso posterior Firefox foram
reexaminados. Foi executado somente um par WebKit original/sincronizado por
versão hospedada, observando cliques, inscrições do listener, histórico, DOM,
documentos e rede. **2/2 no PR e 2/2 na master** passaram, sem retries/pulos.
Os registros novos mostram, em ambas:

- O clique explícito no link Projetos foi interceptado pela aplicação; o
  `pushState` para Projetos precedeu o H1. Não foi o skip que iniciou esse commit.
- Voltar emitiu `popstate` para a 404, com o listener pronto; houve requisição de
  documento com resposta 404 e um novo documento hidratado. Nenhuma escrita de
  histórico para Projetos foi registrada depois desse Voltar.
- Nos casos originais, prefetch de Nana e imagem ainda estava pendente e foi
  cancelado ao voltar; na master, também houve cancelamento de prefetch de Sobre.
  Isso não é evidência de uma navegação de usuário para essas rotas. Nos casos
  sincronizados não houve esses cancelamentos na etapa final.

[Comparação com tempos e eventos](evidencias/bskip-continuacao/comparacao.json).
O observador acrescenta avaliações de leitura e pode alterar temporização.
Esses PASS demonstram recuperação correta nas condições capturadas; não apagam
o incidente nem provam sua causa ou ausência de regressão. Atraso artificial do
listener, da etapa anterior, continua apenas um mecanismo possível preexistente.

**Causa exclusiva de B/skip: indeterminada.** A sincronização corrige precondições
insuficientes do teste e pode evitar uma corrida ao postergar Voltar. Não foi
demonstrado que ela corrige um defeito da aplicação, nem que o incidente depende
exclusivamente da hidratação. Não se atribui a falha ao Next ou ao FragmentHistory.

### Validação e decisão

Tipos, lint dos três arquivos, Prettier e `git diff --check` aprovados. Tipos/lint
usaram a cópia limpa com os mesmos hashes da worktree, preservando os diagnósticos
não rastreados desta. A revisão independente e os 3/3 locais e 6/6 hospedados do
diff final continuam válidos. Para B/skip no diff final, os três motores têm PASS
hospedado: Chromium **1/1 novo**, Firefox/WebKit **1/1 cada reaproveitado**.
Aplicação, lockfile, Node, origem e BUILD_ID continuam os mesmos; não foi
necessário novo build, auditoria completa ou reexecução de A/C. Comandos,
identidades e limites em [validacao.json](evidencias/bskip-continuacao/validacao.json).
O CI verde remoto continua ligado ao head original, não a um futuro commit deste diff.

**NO-GO de homologação mantido.** B/skip exige capturar a falha natural com essa
telemetria ou uma decisão formal do proprietário aceitando explicitamente o risco
residual e a homologação incompleta, com acompanhamento independente. Passagens
posteriores não substituem essa decisão. Não houve autorização/dispensa nesta tarefa.

Na #45/T113, falta avaliação humana com teclado e leitor de tela real do fluxo
skip → Tab, incluindo ausência de perda tardia de foco e orientação na recuperação
da 404; decidir e registrar o impacto/aceite. Isso é distinto das inspeções gerais
de T055 (demais rotas, zoom, aparelho físico etc.), que permanecem abertas.
T113 também aguarda o CI do eventual novo head após envio autorizado.
Não houve alteração de dependências, master, código da aplicação, merge ou deploy.
