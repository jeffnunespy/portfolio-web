# Inventário de evidências

Consolidação de 06/11/2026 para head `3736977`, master integral `0d69203` e
Preview `i_qv7YR4GKIqrXi-ZwgRu`. Os originais continuam em
`/tmp/pr47-option-a-20261106`; nada foi apagado dos checkouts ou diretórios antigos.

| Arquivo                                                                                  | Conteúdo                                                                                                                                           |
| ---------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| `isolation.json`, `build-identities.json`, `preview-identity.json`, `vercel-inspect.log` | Caminhos reais, hashes de fontes/lock/.nvmrc e identidades dos artefatos.                                                                          |
| `ci-excerpts.txt`                                                                        | Trechos do job quality real, com vínculo head/base/merge sintético/BUILD_ID e resultados.                                                          |
| `recovered-hosted-evidence.json`, `recovered-hosted-source-v1.cjs.txt`                   | Recuperação sanitizada das saídas reais de ferramentas e da sonda anterior; fonte, linhas, data, hash e limites. Sem helper de autenticação.       |
| `results-head.json`, `head-targeted-network.log`                                         | Rodada local efetiva: 80 aprovados, 1 falha.                                                                                                       |
| `results-head-repeat.json`, `head-repeat.log`                                            | Três repetições isoladas do caso Chromium: todas aprovadas; não anulam a primeira falha.                                                           |
| `preview-results.json`, `preview-targeted.log`, `preview-failures.json`                  | Rodada hospedada: 75 aprovados, 6 falhas preservadas.                                                                                              |
| `keyboard-results.json`, `keyboard-preview.log`                                          | Complemento de teclado e foco visível hospedado: 3 aprovados.                                                                                      |
| `diagnostic-v2-head.json`, `diagnostic-v2-master.json`, logs correspondentes             | Cada versão com 3 controles aprovados e 6 falhas da reprodução independente.                                                                       |
| `diagnostic-comparison.json`                                                             | Amostras de URL/H1/foco/histórico e navegações de documento, por versão/método/motor.                                                              |
| `diagnostic-master.json`, `diagnostic-master.log`                                        | Primeira versão diagnóstica: 5 aprovados/4 falhas, sem asserção de ausência de recarga; preservada para não perder o limite metodológico.          |
| `negative-control.json`, `negative-control.log`, `controle-negativo-artefatos.tar.gz`    | Controle negativo renovado: três falhas de foco Chromium na master integral, com teste idêntico ao da candidata.                                   |
| `result-matrix.json`                                                                     | Índice por teste, navegador, status, duração e localização da falha.                                                                               |
| `independent-review.md`                                                                  | Parecer final independente, incluindo limites e NO-GO.                                                                                             |
| `artefatos-rodadas.tar.gz`                                                               | Traces locais, anexos e contextos de erro de todas as rodadas efetivas, com pastas separadas. Preview sem trace para não gravar headers de acesso. |
| `*-build*.log`, `head-targeted.log`                                                      | Builds e tentativa inicial de servidor, incluindo falhas ambientais; não contam como aprovação.                                                    |
| `credential-scan.json`                                                                   | Busca por valores exatos de credenciais Vercel, inclusive nos ZIPs, feita em memória antes da cópia; nenhuma correspondência.                      |
| `*.config.ts.txt`, `*.spec.ts.txt`                                                       | Harnesses temporários e testes de reprodução preservados como texto, fora de coleta por testes, TypeScript ou lint do repositório.                 |
| `SHA256SUMS`                                                                             | Integridade dos artefatos consolidados.                                                                                                            |

O arquivo compactado mantém os nomes `results-head`, `results-head-repeat`,
`diagnostic-results-master`, `diagnostic-v2-results-head`,
`diagnostic-v2-results-master`, `preview-results` e `keyboard-results`. Os caminhos
absolutos nos JSONs apontam para os originais; os anexos correspondentes estão
também no arquivo compactado. Todos os testes novos efetivos usaram zero retries.

## Comandos e reprodução

As fontes foram extraídas por `git archive` dos dois commits completos. Dependências
já existentes foram copiadas fisicamente com `cp -a --reflink=auto`; não houve
instalação. Caminhos reais foram verificados antes de qualquer escrita. Em cada
cópia, o build usou Node 24.22.2 e `NEXT_PUBLIC_SITE_URL=https://portfolio.example`.

Comandos efetivos abaixo foram executados a partir da cópia indicada, com o PATH
apontando para `/home/jeff/.nvm/versions/node/v24.22.2/bin`:

```sh
rtk proxy npm run build
rtk proxy node node_modules/@playwright/test/cli.js test --config playwright.option-a.config.ts
rtk proxy node node_modules/@playwright/test/cli.js test --config playwright.repeat.config.ts --project chromium --grep 'skip da 404 cancela commit' --repeat-each 3
rtk proxy node node_modules/@playwright/test/cli.js test --config playwright.diagnostic.config.ts
rtk proxy node node_modules/@playwright/test/cli.js test --config playwright.diagnostic-v2.config.ts
```

`option-a` e `repeat` rodaram no head. Diagnóstico v1 rodou na master; v2 rodou em
ambas. O controle negativo rodou na master com `playwright.negative.config.ts`,
`--project chromium --grep "issue #45 - direta:" --repeat-each 3`, na porta 3002. Portas exclusivas: local dirigido 3001, master diagnóstico 3002, head
diagnóstico v2 3003. Os servidores eram iniciados pela própria configuração, com
`reuseExistingServer: false`.

Para reproduzir a pendência, copiar `pending-history.spec.ts.txt` para
`diagnostics-v2/pending-history.spec.ts` **numa nova cópia isolada** e a configuração
diagnóstica correspondente para o nome sem `.txt`. Conferir novamente os caminhos
reais, a identidade, dependências existentes e portas livres antes da execução.
Não colocar o teste em `tests/e2e` nem mudar os gates para absorver a falha.

Os testes hospedados usaram configurações próprias e o acesso existente em memória,
com `PREVIEW_URL` no deployment imutável. Não foi salvo o segredo de bypass.
`head-playwright.preview.config.ts.txt` preserva a configuração sem valores de
credenciais; `keyboard-smoke.spec.ts.txt`, o complemento. A cópia hospedada do
histórico diferiu da fonte somente no glob de chunks, de
`**/_next/static/chunks/*.js` para `**/_next/static/**/chunks/*.js`. As asserções
permaneceram iguais. O runner não publicou nem reconfigurou o deployment.

Consultar o [relatório](../relatorio.md) para a interpretação. Um status PASS
histórico, um exit 0 de sonda com erros capturados ou três repetições positivas
não substituem as falhas e lacunas atuais.
