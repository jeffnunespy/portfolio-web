# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c-forward.spec.ts >> C - Avançar cedo após recarga da 404
- Location: triage-abc-tests/c-forward.spec.ts:2:46

# Error details

```
Test timeout of 45000ms exceeded.
```

```
Error: page.goForward: Test timeout of 45000ms exceeded.
Call log:
  - waiting for navigation until "load"
    - navigated to "http://localhost:3101/rota-inexistente#main-content"

```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - link "Pular para o conteúdo principal" [ref=f1e2] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=f1e3]:
    - generic [ref=f1e4]:
      - link "Jefferson Nunes — Início" [ref=f1e5] [cursor=pointer]:
        - /url: /
        - generic [ref=f1e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=f1e7]:
        - link "Início" [ref=f1e8] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=f1e10] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=f1e12] [cursor=pointer]:
          - /url: /roadmap
          - generic [ref=f1e13]: Roadmap
        - link "Sobre" [ref=f1e14] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=f1e16] [cursor=pointer]:
          - /url: /curriculo
          - generic [ref=f1e17]: Currículo
  - main [active] [ref=f1e18]:
    - generic [ref=f1e20]:
      - generic [ref=f1e21]:
        - heading "Página não encontrada" [level=1] [ref=f1e22]
        - paragraph [ref=f1e23]: HTTP 404 · Registro inexistente
        - paragraph [ref=f1e24]: A página que você procura não existe ou foi removida.
        - link "Voltar para a página inicial" [ref=f1e25] [cursor=pointer]:
          - /url: /
        - link "Ver todos os projetos" [ref=f1e26] [cursor=pointer]:
          - /url: /projetos
      - generic [ref=f1e27]:
        - generic [ref=f1e28]:
          - term [ref=f1e29]: Acervo publicado
          - definition [ref=f1e30]: 2 fichas
        - generic [ref=f1e31]:
          - term [ref=f1e32]: Escopo planejado
          - definition [ref=f1e33]: 4 entradas
        - generic [ref=f1e34]:
          - term [ref=f1e35]: Destino de retorno
          - definition [ref=f1e36]: Página inicial
  - contentinfo [ref=f1e37]:
    - generic [ref=f1e38]:
      - navigation "Links secundários" [ref=f1e39]:
        - link "Início" [ref=f1e40] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=f1e41] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap" [ref=f1e42] [cursor=pointer]:
          - /url: /roadmap
        - link "Sobre" [ref=f1e43] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo" [ref=f1e44] [cursor=pointer]:
          - /url: /curriculo
      - region [ref=f1e45]:
        - heading "Vamos conversar." [level=2] [ref=f1e46]
        - paragraph [ref=f1e47]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=f1e48]:
          - link "Enviar e-mail" [ref=f1e49] [cursor=pointer]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=f1e50] [cursor=pointer]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=f1e51] [cursor=pointer]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=f1e52]: © 2026 Jefferson Nunes. Todos os direitos reservados.
```

# Test source

```ts
  1  | import {test,expect} from "@playwright/test";
  2  | for (const fase of ['cedo','hidratado']) test(`C - Avançar ${fase} após recarga da 404`, async ({page}) => {
  3  |   let liberar!: () => void;
  4  |   const portao = new Promise<void>((resolve) => (liberar = resolve));
  5  |   let retidas = 0;
  6  |   let arvoreRecebida = false;
  7  |   page.on("requestfinished", (requisicao) => {
  8  |     if (
  9  |       new URL(requisicao.url()).pathname === "/sobre" &&
  10 |       requisicao.headers()["next-router-segment-prefetch"] === "/_tree"
  11 |     ) {
  12 |       arvoreRecebida = true;
  13 |     }
  14 |   });
  15 |   await page.route(
  16 |     (url) => url.pathname === "/sobre",
  17 |     async (rota) => {
  18 |       const requisicao = rota.request();
  19 |       if (
  20 |         requisicao.resourceType() === "document" ||
  21 |         requisicao.headers()["next-router-segment-prefetch"] === "/_tree"
  22 |       ) {
  23 |         return rota.continue();
  24 |       }
  25 |       retidas++;
  26 |       await portao;
  27 |       await rota.continue().catch(() => {});
  28 |     },
  29 |   );
  30 |   await page.goto("/rota-inexistente");
  31 |   await expect.poll(() => arvoreRecebida).toBe(true);
  32 |   await expect.poll(() => retidas).toBeGreaterThan(0);
  33 |   await page
  34 |     .getByRole("navigation", { name: "Navegação principal" })
  35 |     .getByRole("link", { name: "Sobre", exact: true })
  36 |     .click();
  37 |   await page.waitForTimeout(300);
  38 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  39 |   await page.locator(".skip-link").focus();
  40 |   await page.keyboard.press("Enter");
  41 |   await expect(page.locator("main")).toBeFocused();
  42 |   await page.keyboard.press("Tab");
  43 |   const voltar = page.getByRole("link", { name: "Voltar para a página inicial" });
  44 |   await expect(voltar).toBeFocused();
  45 |   liberar();
  46 |   await page.waitForLoadState("networkidle");
  47 |   await page.waitForTimeout(500);
  48 |   await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
  49 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  50 |   await expect(voltar).toBeFocused();
  51 |   let bloquear = true;
  52 |   let retidos = 0;
  53 |   let soltar!: () => void;
  54 |   const barreira = new Promise<void>(r => soltar=r);
  55 |   await page.route('**/_next/static/**/chunks/*.js', async route => {
  56 |     if (bloquear) {retidos++; await barreira;}
  57 |     await route.continue().catch(()=>{});
  58 |   });
  59 |   await page.goBack();
  60 |   await expect(page).toHaveURL(/\/rota-inexistente$/);
  61 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  62 |   await expect.poll(()=>retidos).toBeGreaterThan(0);
  63 |   expect(await page.evaluate(() => Object.keys(document.querySelector('header a')!).some(k=>k.startsWith('__reactFiber')))).toBe(false);
  64 |   if (fase === 'hidratado') {
  65 |     bloquear = false; soltar();
  66 |     await page.waitForFunction(() => (window as any).__captureReady);
  67 |     await page.waitForLoadState('networkidle');
  68 |   }
> 69 |   await page.goForward();
     |              ^ Error: page.goForward: Test timeout of 45000ms exceeded.
  70 |   if (fase === 'cedo') {bloquear = false; soltar();}
  71 |   await page.waitForLoadState('networkidle');
  72 |   await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
  73 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  74 | });
  75 | 
  76 | test.beforeEach(async ({page})=> {
  77 |  const log:unknown[]=[];(page as any).__log=log;
  78 |  await page.exposeFunction('triageEvent',(e:unknown)=>log.push(e));
  79 |  await page.addInitScript(()=>{
  80 |  const original=window.addEventListener;
  81 |  window.addEventListener=function(type:any,listener:any,options:any){
  82 |  const res=original.call(this,type,listener,options);
  83 |  if(type==='popstate' && options===true) {(window as any).__captureReady=true;(window as any).triageEvent({kind:'capture-ready',t:performance.now(),url:location.href});}
  84 |  return res;} as any;
  85 |  const snap=(kind:string,e?:any)=>(window as any).triageEvent({kind,t:performance.now(),url:location.href,stateNull:history.state===null,ready:!!(window as any).__captureReady,h1:document.querySelector('h1')?.textContent,trusted:e?.isTrusted});
  86 |  for(const kind of ['popstate','hashchange','pageshow','pagehide']) original.call(window,kind,(e:Event)=>snap(kind,e));
  87 |  for(const method of ['pushState','replaceState'] as const){
  88 |  const originalHistory=History.prototype[method];
  89 |  History.prototype[method]=function(...args:any[]){const result=originalHistory.apply(this,args as any);snap(method);return result;};
  90 |  }
  91 |  });
  92 | });
  93 | test.afterEach(async({page},info)=>{await info.attach('events',{body:JSON.stringify((page as any).__log),contentType:'application/json'});});
  94 | 
```