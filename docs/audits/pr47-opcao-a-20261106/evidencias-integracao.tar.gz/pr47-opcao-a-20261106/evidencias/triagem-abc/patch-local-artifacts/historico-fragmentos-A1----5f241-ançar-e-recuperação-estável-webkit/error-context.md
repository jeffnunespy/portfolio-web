# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico-fragmentos.spec.ts >> A1 - 404 genérica: pré-hidratação, Voltar/Avançar e recuperação estável
- Location: tests/e2e/historico-fragmentos.spec.ts:244:7

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "/localhost:3103/projetos/nana-silva?_rsc=F7ufU-sfG9N3x5EV due to access control checks.",
+ ]
```

# Page snapshot

```yaml
- generic [ref=f4e1]:
  - link "Pular para o conteúdo principal" [ref=f4e2]:
    - /url: "#main-content"
  - banner [ref=f4e3]:
    - generic [ref=f4e4]:
      - link "Jefferson Nunes — Início" [ref=f4e5]:
        - /url: /
        - generic [ref=f4e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=f4e7]:
        - link "Início" [ref=f4e8]:
          - /url: /
        - link "Projetos" [ref=f4e10]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=f4e12]:
          - /url: /roadmap
          - generic [ref=f4e13]: Roadmap
        - link "Sobre" [ref=f4e14]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=f4e16]:
          - /url: /curriculo
          - generic [ref=f4e17]: Currículo
  - main [active] [ref=f4e18]:
    - generic [ref=f4e20]:
      - generic [ref=f4e21]:
        - heading "Página não encontrada" [level=1] [ref=f4e22]
        - paragraph [ref=f4e23]: HTTP 404 · Registro inexistente
        - paragraph [ref=f4e24]: A página que você procura não existe ou foi removida.
        - link "Voltar para a página inicial" [ref=f4e25]:
          - /url: /
        - link "Ver todos os projetos" [ref=f4e26]:
          - /url: /projetos
      - generic [ref=f4e27]:
        - generic [ref=f4e28]:
          - term [ref=f4e29]: Acervo publicado
          - definition [ref=f4e30]: 2 fichas
        - generic [ref=f4e31]:
          - term [ref=f4e32]: Escopo planejado
          - definition [ref=f4e33]: 4 entradas
        - generic [ref=f4e34]:
          - term [ref=f4e35]: Destino de retorno
          - definition [ref=f4e36]: Página inicial
  - contentinfo [ref=f4e37]:
    - generic [ref=f4e38]:
      - navigation "Links secundários" [ref=f4e39]:
        - link "Início" [ref=f4e40]:
          - /url: /
        - link "Projetos" [ref=f4e41]:
          - /url: /projetos
        - link "Roadmap" [ref=f4e42]:
          - /url: /roadmap
        - link "Sobre" [ref=f4e43]:
          - /url: /sobre
        - link "Currículo" [ref=f4e44]:
          - /url: /curriculo
      - region [ref=f4e45]:
        - heading "Vamos conversar." [level=2] [ref=f4e46]
        - paragraph [ref=f4e47]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=f4e48]:
          - link "Enviar e-mail" [ref=f4e49]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=f4e50]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=f4e51]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=f4e52]: © 2026 Jefferson Nunes. Todos os direitos reservados.
  - alert [ref=f4e53]
```

# Test source

```ts
  131 |     type No = [string | [string, string, string], Record<string, No>];
  132 |     let no = (history.state as { __PRIVATE_NEXTJS_INTERNALS_TREE?: { tree?: No } } | null)
  133 |       ?.__PRIVATE_NEXTJS_INTERNALS_TREE?.tree;
  134 |     if (!no) return history.state === null ? "estado nulo" : "sem árvore";
  135 |     const segmentos: string[] = [];
  136 |     while (no) {
  137 |       const segmento = Array.isArray(no[0]) ? no[0][1] : no[0];
  138 |       if (segmento && !segmento.startsWith("__PAGE__")) segmentos.push(segmento);
  139 |       no = no[1]?.children;
  140 |     }
  141 |     return "/" + segmentos.join("/");
  142 |   });
  143 |   test.info().annotations.push({ type: `árvore gravada (${momento})`, description: rota });
  144 | }
  145 | 
  146 | const navegar = (page: Page, rotulo: string) =>
  147 |   page
  148 |     .getByRole("navigation", { name: "Navegação principal" })
  149 |     .getByRole("link", { name: rotulo, exact: true })
  150 |     .click();
  151 | 
  152 | test("F1 - skip link: Voltar e Avançar mantêm URL e conteúdo coerentes", async ({
  153 |   page,
  154 |   browser,
  155 | }) => {
  156 |   await abrir(page, "/");
  157 |   await pularParaConteudo(page);
  158 |   await navegar(page, "Sobre");
  159 |   await esperarRota(page, browser, "/sobre");
  160 | 
  161 |   await page.goBack();
  162 |   await esperarRota(page, browser, "/#main-content");
  163 |   await page.goForward();
  164 |   await esperarRota(page, browser, "/sobre");
  165 |   await page.goBack();
  166 |   await page.goBack();
  167 |   await esperarRota(page, browser, "/");
  168 | });
  169 | 
  170 | // A1: a 404 genérica usa o fallback de documento do Next. A recuperação deve
  171 | // distinguir entradas nulas e não nulas sem recarregar fragmentos na própria
  172 | // 404 nem substituir a F1 nas rotas válidas.
  173 | async function esperar404Generica(page: Page, url: string) {
  174 |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  175 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  176 |   await expect(page).toHaveTitle("Página não encontrada | Portfólio");
  177 |   await expect(page.locator("main")).toContainText("A página que você procura não existe");
  178 |   await expect(
  179 |     page.getByRole("navigation", { name: "Navegação principal" }).locator("[aria-current]"),
  180 |   ).toHaveCount(0);
  181 |   await hidratar(page);
  182 | }
  183 | 
  184 | async function observarA1(page: Page) {
  185 |   const documentos: { url: string; status: number }[] = [];
  186 |   const requisicoesRsc: string[] = [];
  187 |   const eventos: unknown[] = [];
  188 |   const erros: string[] = [];
  189 |   page.on("response", (resposta) => {
  190 |     if (resposta.request().resourceType() === "document") {
  191 |       documentos.push({ url: resposta.url(), status: resposta.status() });
  192 |     }
  193 |   });
  194 |   page.on("pageerror", (erro) => erros.push(erro.message));
  195 |   page.on("request", (requisicao) => {
  196 |     if (requisicao.headers()["rsc"]) requisicoesRsc.push(requisicao.url());
  197 |   });
  198 |   // O router às vezes aborta a leitura do corpo da RSC já respondida: conta as
  199 |   // requisições encerradas, com ou sem falha.
  200 |   const rscEncerradas: string[] = [];
  201 |   const encerrarRsc = (requisicao: Request) => {
  202 |     if (requisicao.headers()["rsc"]) rscEncerradas.push(new URL(requisicao.url()).pathname);
  203 |   };
  204 |   page.on("requestfinished", encerrarRsc);
  205 |   page.on("requestfailed", encerrarRsc);
  206 |   await page.exposeFunction("registrarHistoricoA1", (evento: unknown) => eventos.push(evento));
  207 |   await page.addInitScript(() => {
  208 |     const janela = window as unknown as Window & {
  209 |       documentoA1?: string;
  210 |       registrarHistoricoA1: (evento: unknown) => Promise<void>;
  211 |     };
  212 |     janela.documentoA1 = crypto.randomUUID();
  213 |     window.addEventListener("popstate", (evento) => {
  214 |       void janela.registrarHistoricoA1({
  215 |         url: location.href,
  216 |         estado: evento.state,
  217 |         titulo: document.title,
  218 |         h1: document.querySelector("h1")?.textContent,
  219 |       });
  220 |     });
  221 |   });
  222 |   const documento = () =>
  223 |     page.evaluate(() => (window as Window & { documentoA1?: string }).documentoA1);
  224 |   const conferirEstabilidade = async () => {
  225 |     await page.waitForLoadState("networkidle");
  226 |     const quantidade = documentos.length;
  227 |     const quantidadeRsc = requisicoesRsc.length;
  228 |     await page.waitForTimeout(700);
  229 |     expect(documentos).toHaveLength(quantidade);
  230 |     expect(requisicoesRsc).toHaveLength(quantidadeRsc);
> 231 |     expect(erros).toEqual([]);
      |                   ^ Error: expect(received).toEqual(expected) // deep equality
  232 |   };
  233 |   const registrar = async () => {
  234 |     await test.info().attach("historico-a1", {
  235 |       body: JSON.stringify({ documentos, requisicoesRsc, eventos, erros }, null, 2),
  236 |       contentType: "application/json",
  237 |     });
  238 |   };
  239 |   const rscEncerradasDe = (rota: string) => rscEncerradas.filter((p) => p === rota).length;
  240 |   return { documentos, documento, conferirEstabilidade, registrar, rscEncerradasDe };
  241 | }
  242 | 
  243 | for (const entrada of ["skip", "hash direto", "location.hash", "pré-hidratação"] as const) {
  244 |   test(`A1 - 404 genérica: ${entrada}, Voltar/Avançar e recuperação estável`, async ({ page }) => {
  245 |     const observacao = await observarA1(page);
  246 |     const rota = "/rota-inexistente";
  247 |     const url = rota + "#main-content";
  248 |     if (entrada === "pré-hidratação") {
  249 |       const liberar = await pularAntesDaHidratacao(page, rota);
  250 |       liberar();
  251 |       await hidratar(page);
  252 |     } else {
  253 |       await abrir(page, entrada === "hash direto" ? url : rota);
  254 |       if (entrada === "skip") await pularParaConteudo(page);
  255 |       if (entrada === "location.hash") {
  256 |         await page.evaluate(() => {
  257 |           location.hash = "main-content";
  258 |         });
  259 |         await expect(page.locator("main")).toBeFocused();
  260 |       }
  261 |     }
  262 |     await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  263 |     // #45: o estado restaurado pelo Next pertence à 404 confirmada.
  264 |     await expect.poll(() => page.evaluate(() => history.state !== null)).toBe(true);
  265 |     const inicial = await observacao.documento();
  266 |     const entradas = await page.evaluate(() => history.length);
  267 |     await observacao.conferirEstabilidade();
  268 |     expect(observacao.documentos).toHaveLength(1);
  269 |     expect(observacao.documentos[0].status).toBe(404);
  270 | 
  271 |     await page
  272 |       .getByRole("navigation", { name: "Navegação principal" })
  273 |       .getByRole("link", { name: "Sobre", exact: true })
  274 |       .focus();
  275 |     await page.keyboard.press("Enter");
  276 |     await expect(page.locator("h1")).toHaveText("Sobre");
  277 |     await expect(page).toHaveTitle("Sobre | Portfólio");
  278 |     expect(await observacao.documento()).toBe(inicial);
  279 | 
  280 |     await page.goBack();
  281 |     await esperar404Generica(page, url);
  282 |     expect(await observacao.documento()).not.toBe(inicial);
  283 |     expect(await page.evaluate(() => history.length)).toBe(entradas + 1);
  284 |     expect(observacao.documentos).toHaveLength(2);
  285 |     expect(observacao.documentos[1].status).toBe(404);
  286 |     // A recarga pode restaurar BODY (histórico salvo antes da hidratação) ou
  287 |     // MAIN (abertura do hash), como nos controles nativos da mesma 404.
  288 |     const foco = await page.evaluate(() => ({
  289 |       tag: document.activeElement?.tagName,
  290 |       id: document.activeElement?.id,
  291 |     }));
  292 |     expect([
  293 |       { tag: "MAIN", id: "main-content" },
  294 |       { tag: "BODY", id: "" },
  295 |     ]).toContainEqual(foco);
  296 |     // #45: restaurar a 404 confirmada não pede RSC nem repete o fragmento.
  297 |     const rscAntesDoSkip = observacao.rscEncerradasDe(rota);
  298 |     await pularParaConteudoFocado(page);
  299 |     await page.keyboard.press("Tab");
  300 |     const voltarParaInicio = page.getByRole("link", { name: "Voltar para a página inicial" });
  301 |     await expect(voltarParaInicio).toBeFocused();
  302 |     await observacao.conferirEstabilidade();
  303 |     await expect(voltarParaInicio).toBeFocused();
  304 |     expect(observacao.rscEncerradasDe(rota)).toBe(rscAntesDoSkip);
  305 | 
  306 |     await page.goForward();
  307 |     await expect(page).toHaveURL(/\/sobre$/);
  308 |     await expect(page.locator("h1")).toHaveText("Sobre");
  309 |     await page.goBack();
  310 |     await esperar404Generica(page, url);
  311 |     await observacao.conferirEstabilidade();
  312 |     expect(await page.evaluate(() => history.length)).toBe(entradas + 1);
  313 |     const resposta = await page.reload();
  314 |     expect(resposta?.status()).toBe(404);
  315 |     await esperar404Generica(page, url);
  316 |     await navegar(page, "Projetos");
  317 |     await expect(page.locator("h1")).toHaveText("Projetos");
  318 |     await page.goBack();
  319 |     await esperar404Generica(page, url);
  320 |     await observacao.conferirEstabilidade();
  321 |     await observacao.registrar();
  322 |   });
  323 | }
  324 | 
  325 | test("A1 - fragmentos na própria 404 são nativos e não recarregam", async ({ page }) => {
  326 |   const observacao = await observarA1(page);
  327 |   await abrir(page, "/rota-inexistente");
  328 |   const inicial = await observacao.documento();
  329 |   await pularParaConteudo(page);
  330 |   await page.evaluate(() => {
  331 |     location.hash = "outro-fragmento";
```