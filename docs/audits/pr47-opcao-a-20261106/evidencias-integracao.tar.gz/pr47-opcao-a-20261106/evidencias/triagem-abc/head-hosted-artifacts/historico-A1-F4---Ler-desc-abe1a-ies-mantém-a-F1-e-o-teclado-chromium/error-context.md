# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico.spec.ts >> A1/F4 - Ler descrição nas três superfícies mantém a F1 e o teclado
- Location: triage-abc-tests/historico.spec.ts:362:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "contexto"
Received: undefined

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=f4e1]:
  - link "Pular para o conteúdo principal" [ref=f4e2] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=f4e3]:
    - generic [ref=f4e4]:
      - link "Jefferson Nunes — Início" [ref=f4e5] [cursor=pointer]:
        - /url: /
        - generic [ref=f4e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=f4e7]:
        - link "Início" [ref=f4e8] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=f4e10] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=f4e12] [cursor=pointer]:
          - /url: /roadmap
          - generic [ref=f4e13]: Roadmap
        - link "Sobre" [active] [ref=f4e14] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=f4e16] [cursor=pointer]:
          - /url: /curriculo
          - generic [ref=f4e17]: Currículo
  - main [ref=f4e18]:
    - article [ref=f4e19]:
      - generic [ref=f4e20]:
        - heading "Plataforma de Portfólio" [level=1] [ref=f4e21]
        - paragraph [ref=f4e23]: Ficha · plataforma-portfolio
        - paragraph [ref=f4e24]: Portfólio pessoal construído com Next.js para apresentar projetos e trajetória profissional de forma estruturada.
        - group "Classificação do projeto" [ref=f4e25]:
          - generic [ref=f4e26]: Em andamento
          - generic [ref=f4e27]: Web
          - generic [ref=f4e28]: Autoral
        - navigation "Nesta ficha" [ref=f4e29]:
          - list [ref=f4e30]:
            - listitem [ref=f4e31]:
              - link "Contexto" [ref=f4e32] [cursor=pointer]:
                - /url: "#contexto"
            - listitem [ref=f4e33]:
              - link "Minha responsabilidade" [ref=f4e34] [cursor=pointer]:
                - /url: "#minha-responsabilidade"
            - listitem [ref=f4e35]:
              - link "Decisões" [ref=f4e36] [cursor=pointer]:
                - /url: "#decisoes"
            - listitem [ref=f4e37]:
              - link "Limitações" [ref=f4e38] [cursor=pointer]:
                - /url: "#limitacoes"
      - region [ref=f4e39]:
        - heading "Apresentação e fontes" [level=2] [ref=f4e40]
        - figure [ref=f4e41]:
          - generic [ref=f4e42]:
            - link "Ler descrição de Plataforma de Portfólio" [ref=f4e43] [cursor=pointer]:
              - /url: "#contexto"
            - paragraph [ref=f4e44]: Prévia ilustrativa. Se a prévia não aparecer, a descrição do projeto continua disponível.
        - generic [ref=f4e46]:
          - paragraph [ref=f4e47]: Fonte e verificação
          - generic [ref=f4e49]:
            - paragraph [ref=f4e50]: O código-fonte deste projeto é privado e pode ser disponibilizado para avaliação mediante solicitação.
            - link "Solicitar acesso ao código" [ref=f4e51] [cursor=pointer]:
              - /url: mailto:jeffnunesxavier@gmail.com?subject=Acesso ao código do projeto
      - generic [ref=f4e52]:
        - generic [ref=f4e53]:
          - heading "Contexto" [level=2] [ref=f4e54]
          - paragraph [ref=f4e55]: Projeto pessoal criado para reunir a apresentação profissional e fichas de projeto em um site versionado, distinguindo trabalho implementado de estruturas de conteúdo planejadas.
          - paragraph [ref=f4e56]:
            - strong [ref=f4e57]: "Problema tratado:"
            - text: Falta de um canal único e versionado para apresentar projetos, competências e trajetória a recrutadores e clientes.
        - generic [ref=f4e58]:
          - heading "Objetivo" [level=2] [ref=f4e59]
          - paragraph [ref=f4e60]: Oferecer uma experiência pública clara, rápida e mantida via conteúdo versionado em arquivos JSON.
        - generic [ref=f4e61]:
          - heading "Funcionalidades principais" [level=2] [ref=f4e62]
          - list [ref=f4e63]:
            - listitem [ref=f4e64]: Listagem de projetos em destaque na página inicial
            - listitem [ref=f4e65]: Página resumida individual por projeto
            - listitem [ref=f4e66]: Página de currículo consultável em HTML
        - generic [ref=f4e67]:
          - heading "Minha responsabilidade" [level=2] [ref=f4e68]
          - paragraph [ref=f4e69]: Responsável por toda a especificação, arquitetura, implementação e conteúdo do site.
        - generic [ref=f4e70]:
          - heading "Decisões relevantes" [level=2] [ref=f4e71]
          - generic [ref=f4e72]:
            - article [ref=f4e73]:
              - heading "Conteúdo versionado em JSON" [level=3] [ref=f4e74]
              - paragraph [ref=f4e75]: Optou-se por armazenar projetos e perfil como arquivos JSON no repositório em vez de um CMS, simplificando a operação nesta fase inicial.
            - article [ref=f4e76]:
              - heading "Uso do Next.js App Router" [level=3] [ref=f4e77]
              - paragraph [ref=f4e78]: Escolhido pela geração estática das páginas de projeto, favorecendo desempenho e simplicidade de deploy.
        - generic [ref=f4e79]:
          - heading "Stack" [level=2] [ref=f4e80]
          - list [ref=f4e81]:
            - listitem [ref=f4e82]: Next.js
            - listitem [ref=f4e83]: TypeScript
            - listitem [ref=f4e84]: React
            - listitem [ref=f4e85]: CSS puro
        - generic [ref=f4e86]:
          - heading "Limitações conhecidas" [level=2] [ref=f4e87]
          - list [ref=f4e88]:
            - listitem [ref=f4e89]: Não há área administrativa; qualquer alteração de conteúdo exige editar arquivos e publicar novo deploy.
        - generic [ref=f4e90]:
          - heading "Próximos passos" [level=2] [ref=f4e91]
          - list [ref=f4e92]:
            - listitem [ref=f4e93]: Executar e registrar as verificações manuais de acessibilidade e o preview antes da publicação
      - generic [ref=f4e94]:
        - generic [ref=f4e95]:
          - link "← Todas as fichas" [ref=f4e96] [cursor=pointer]:
            - /url: /projetos
          - generic [ref=f4e97]:
            - generic [ref=f4e98]: Ficha 2 de 2
            - generic [ref=f4e99]: 2 / 2
        - navigation "Navegação entre fichas de projeto" [ref=f4e100]:
          - link "← Ficha anterior Nana Silva" [ref=f4e101] [cursor=pointer]:
            - /url: /projetos/nana-silva
            - generic [ref=f4e102]: ← Ficha anterior
            - strong [ref=f4e103]: Nana Silva
        - region [ref=f4e104]:
          - generic [ref=f4e105]:
            - heading "Continue pelo currículo" [level=2] [ref=f4e106]
            - paragraph [ref=f4e107]: Veja o resumo profissional, as competências técnicas e os perfis em uma visão consolidada.
          - link "Ver currículo" [ref=f4e108] [cursor=pointer]:
            - /url: /curriculo
  - contentinfo [ref=f4e109]:
    - generic [ref=f4e110]:
      - navigation "Links secundários" [ref=f4e111]:
        - link "Início" [ref=f4e112] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=f4e113] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap" [ref=f4e114] [cursor=pointer]:
          - /url: /roadmap
        - link "Sobre" [ref=f4e115] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo" [ref=f4e116] [cursor=pointer]:
          - /url: /curriculo
      - region [ref=f4e117]:
        - heading "Vamos conversar." [level=2] [ref=f4e118]
        - paragraph [ref=f4e119]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=f4e120]:
          - link "Enviar e-mail" [ref=f4e121] [cursor=pointer]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=f4e122] [cursor=pointer]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=f4e123] [cursor=pointer]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=f4e124]: © 2026 Jefferson Nunes. Todos os direitos reservados.
  - alert [ref=f4e125]: Plataforma de Portfólio
```

# Test source

```ts
  1   | import { test, expect, type Browser, type Page, type Request } from "@playwright/test";
  2   | 
  3   | // F1 (AUD03): depois de navegar por fragmento, Voltar/Avançar precisam manter
  4   | // URL e conteúdo coerentes. Cada passo compara título, h1 e item atual da
  5   | // navegação com os da mesma rota aberta diretamente.
  6   | 
  7   | type Referencia = { titulo: string; h1: string; navAtual: string | null };
  8   | const referencias = new Map<string, Referencia>();
  9   | 
  10  | async function referencia(browser: Browser, rota: string): Promise<Referencia> {
  11  |   const salva = referencias.get(rota);
  12  |   if (salva) return salva;
  13  |   const page = await browser.newPage();
  14  |   await page.goto(rota);
  15  |   const atual = page
  16  |     .getByRole("navigation", { name: "Navegação principal" })
  17  |     .locator('[aria-current="page"]');
  18  |   const nova = {
  19  |     titulo: await page.title(),
  20  |     h1: ((await page.locator("h1").textContent()) ?? "").replace(/\s+/g, " ").trim(),
  21  |     navAtual: (await atual.count()) ? await atual.getAttribute("href") : null,
  22  |   };
  23  |   await page.close();
  24  |   referencias.set(rota, nova);
  25  |   return nova;
  26  | }
  27  | 
  28  | async function esperarRota(page: Page, browser: Browser, url: string) {
  29  |   const [rota, fragmento] = url.split("#");
  30  |   const ref = await referencia(browser, rota);
  31  |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  32  |   await expect(page.locator("h1")).toHaveText(ref.h1);
  33  |   await expect(page).toHaveTitle(ref.titulo);
  34  |   const atual = page
  35  |     .getByRole("navigation", { name: "Navegação principal" })
  36  |     .locator('[aria-current="page"]');
  37  |   if (ref.navAtual) await expect(atual).toHaveAttribute("href", ref.navAtual);
  38  |   else await expect(atual).toHaveCount(0);
  39  |   // Ao voltar de outra rota, só o Chromium atualizou `:target` nas execuções da
  40  |   // AUD03; Firefox e WebKit do Playwright o deixaram nulo, e o Voltar comum do
  41  |   // App Router também não restaura a rolagem nesses casos. O projeto não usa
  42  |   // `:target` em CSS, então a coerência é verificada por URL e conteúdo.
  43  |   if (fragmento && browser.browserType().name() === "chromium") {
  44  |     await expect
  45  |       .poll(() => page.evaluate(() => document.querySelector(":target")?.id))
> 46  |       .toBe(fragmento);
      |        ^ Error: expect(received).toBe(expected) // Object.is equality
  47  |   }
  48  | }
  49  | 
  50  | async function hidratar(page: Page) {
  51  |   await page.waitForFunction(() => {
  52  |     const marca = document.querySelector("header a");
  53  |     return (
  54  |       !!marca &&
  55  |       Object.keys(marca).some((k) => k.startsWith("__reactFiber")) &&
  56  |       history.state !== null
  57  |     );
  58  |   });
  59  | }
  60  | 
  61  | async function abrir(page: Page, rota: string) {
  62  |   await page.goto(rota);
  63  |   await hidratar(page);
  64  | }
  65  | 
  66  | async function pularParaConteudo(page: Page) {
  67  |   await page.keyboard.press("Tab");
  68  |   await expect(page.locator("a.skip-link")).toBeFocused();
  69  |   await page.keyboard.press("Enter");
  70  |   await expect(page.locator("main#main-content")).toBeFocused();
  71  | }
  72  | 
  73  | // Aciona o skip link no HTML pré-renderizado, com os chunks retidos: a entrada
  74  | // de "/" fica sem estado. Devolve a função que libera os chunks.
  75  | async function pularAntesDaHidratacao(page: Page, rota = "/") {
  76  |   let liberar!: () => void;
  77  |   let retidos = 0;
  78  |   const portao = new Promise<void>((resolve) => (liberar = resolve));
  79  |   await page.route("**/_next/static/**/chunks/*.js", async (rota) => {
  80  |     retidos++;
  81  |     await portao;
  82  |     await rota.continue();
  83  |   });
  84  |   await page.goto(rota, { waitUntil: "domcontentloaded" });
  85  |   await pularParaConteudo(page);
  86  |   // Garante que o skip link agiu de fato antes da hidratação.
  87  |   expect(retidos).toBeGreaterThan(0);
  88  |   expect(
  89  |     await page.evaluate(() => {
  90  |       const marca = document.querySelector("header a");
  91  |       return {
  92  |         hidratado: !!marca && Object.keys(marca).some((k) => k.startsWith("__reactFiber")),
  93  |         estado: history.state,
  94  |       };
  95  |     }),
  96  |   ).toEqual({ hidratado: false, estado: null });
  97  |   return liberar;
  98  | }
  99  | 
  100 | // Marca o documento para detectar recarga e coleta erros da página.
  101 | async function vigiar(page: Page) {
  102 |   const erros: string[] = [];
  103 |   page.on("pageerror", (erro) => erros.push(String(erro)));
  104 |   page.on("console", (msg) => {
  105 |     if (msg.type() === "error") erros.push(msg.text());
  106 |   });
  107 |   await page.evaluate(() => {
  108 |     (window as Window & { __documento?: string }).__documento = "inicial";
  109 |   });
  110 |   return async () => {
  111 |     expect(
  112 |       await page.evaluate(() => (window as Window & { __documento?: string }).__documento),
  113 |     ).toBe("inicial");
  114 |     expect(erros).toEqual([]);
  115 |   };
  116 | }
  117 | 
  118 | // Diagnóstico (sem asserção): rota da árvore que o App Router gravou na entrada
  119 | // corrente. É campo interno do Next.js, por isso fica fora das verificações.
  120 | async function anotarArvore(page: Page, momento: string) {
  121 |   const rota = await page.evaluate(() => {
  122 |     type No = [string | [string, string, string], Record<string, No>];
  123 |     let no = (history.state as { __PRIVATE_NEXTJS_INTERNALS_TREE?: { tree?: No } } | null)
  124 |       ?.__PRIVATE_NEXTJS_INTERNALS_TREE?.tree;
  125 |     if (!no) return history.state === null ? "estado nulo" : "sem árvore";
  126 |     const segmentos: string[] = [];
  127 |     while (no) {
  128 |       const segmento = Array.isArray(no[0]) ? no[0][1] : no[0];
  129 |       if (segmento && !segmento.startsWith("__PAGE__")) segmentos.push(segmento);
  130 |       no = no[1]?.children;
  131 |     }
  132 |     return "/" + segmentos.join("/");
  133 |   });
  134 |   test.info().annotations.push({ type: `árvore gravada (${momento})`, description: rota });
  135 | }
  136 | 
  137 | const navegar = (page: Page, rotulo: string) =>
  138 |   page
  139 |     .getByRole("navigation", { name: "Navegação principal" })
  140 |     .getByRole("link", { name: rotulo, exact: true })
  141 |     .click();
  142 | 
  143 | test("F1 - skip link: Voltar e Avançar mantêm URL e conteúdo coerentes", async ({
  144 |   page,
  145 |   browser,
  146 | }) => {
```