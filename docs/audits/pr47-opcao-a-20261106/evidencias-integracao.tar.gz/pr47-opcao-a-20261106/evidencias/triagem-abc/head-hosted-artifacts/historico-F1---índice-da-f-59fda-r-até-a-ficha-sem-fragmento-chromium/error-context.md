# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico.spec.ts >> F1 - índice da ficha: fragmentos diferentes e Voltar até a ficha sem fragmento
- Location: triage-abc-tests/historico.spec.ts:477:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "limitacoes"
Received: undefined

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Pular para o conteúdo principal" [ref=e2] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e3]:
    - generic [ref=e4]:
      - link "Jefferson Nunes — Início" [ref=e5] [cursor=pointer]:
        - /url: /
        - generic [ref=e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=e7]:
        - link "Início" [ref=e8] [cursor=pointer]:
          - /url: /
        - link "Projetos" [active] [ref=e10] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=e12] [cursor=pointer]:
          - /url: /roadmap
          - generic [ref=e13]: Roadmap
        - link "Sobre" [ref=e14] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=e16] [cursor=pointer]:
          - /url: /curriculo
          - generic [ref=e17]: Currículo
  - main [ref=e18]:
    - article [ref=e19]:
      - generic [ref=e20]:
        - heading "Nana Silva" [level=1] [ref=e21]
        - paragraph [ref=e23]: Ficha · nana-silva
        - paragraph [ref=e24]: Portfólio-catálogo de tatuagens com Astro, conteúdo editado no Notion e contato pelo WhatsApp, publicado na Cloudflare.
        - group "Classificação do projeto" [ref=e25]:
          - generic [ref=e26]: Em andamento
          - generic [ref=e27]: Web
          - generic [ref=e28]: Profissional
          - generic [ref=e29]: Em validação
        - navigation "Nesta ficha" [ref=e30]:
          - list [ref=e31]:
            - listitem [ref=e32]:
              - link "Contexto" [ref=e33] [cursor=pointer]:
                - /url: "#contexto"
            - listitem [ref=e34]:
              - link "Minha responsabilidade" [ref=e35] [cursor=pointer]:
                - /url: "#minha-responsabilidade"
            - listitem [ref=e36]:
              - link "Decisões" [ref=e37] [cursor=pointer]:
                - /url: "#decisoes"
            - listitem [ref=e38]:
              - link "Limitações" [ref=e39] [cursor=pointer]:
                - /url: "#limitacoes"
      - region [ref=e40]:
        - heading "Apresentação e fontes" [level=2] [ref=e41]
        - generic [ref=e42]:
          - paragraph [ref=e43]: Fonte e verificação
          - generic [ref=e44]:
            - link "Abrir demonstração" [ref=e45] [cursor=pointer]:
              - /url: https://nana-silva-validacao.pages.dev/
            - generic [ref=e46]:
              - paragraph [ref=e47]: O código-fonte deste projeto é privado e pode ser disponibilizado para avaliação mediante solicitação.
              - link "Solicitar acesso ao código" [ref=e48] [cursor=pointer]:
                - /url: mailto:jeffnunesxavier@gmail.com?subject=Acesso ao código do projeto
      - generic [ref=e49]:
        - generic [ref=e50]:
          - heading "Contexto" [level=2] [ref=e51]
          - paragraph [ref=e52]: Projeto profissional desenvolvido para a tatuadora Nana Silva apresentar seus flashes, informar disponibilidade e receber contatos. A artista mantém o conteúdo em um painel privado no Notion, e o visitante consulta páginas estáticas. O site está publicado em ambiente de validação, com verificações operacionais ainda pendentes.
          - paragraph [ref=e53]:
            - strong [ref=e54]: "Problema tratado:"
            - text: Reunir desenhos de tatuagem e sua disponibilidade em um catálogo que a artista possa atualizar pelo celular, sem editar código, encaminhando os interessados ao WhatsApp.
        - generic [ref=e55]:
          - heading "Objetivo" [level=2] [ref=e56]
          - paragraph [ref=e57]: Permitir que visitantes encontrem um desenho, consultem suas informações e iniciem uma conversa com a artista, mantendo a edição do catálogo acessível pelo celular.
        - generic [ref=e58]:
          - heading "Funcionalidades principais" [level=2] [ref=e59]
          - list [ref=e60]:
            - listitem [ref=e61]: Catálogo de flashes disponíveis e reservados, com páginas individuais e ampliação das artes
            - listitem [ref=e62]: Ações de contato pelo WhatsApp com mensagem preenchida conforme o desenho e sua disponibilidade
            - listitem [ref=e63]: Edição de flashes, textos e dúvidas frequentes em fontes de conteúdo do Notion
            - listitem [ref=e64]: Publicação estática e automação agendada para detectar alterações no conteúdo e solicitar um novo build
            - listitem [ref=e65]: Processamento de imagens com redimensionamento, formatos otimizados e cache de derivados
            - listitem [ref=e66]: Filtro de autorização e revogação para impedir a inclusão de fotos sem autorização no próximo build
        - generic [ref=e67]:
          - heading "Minha responsabilidade" [level=2] [ref=e68]
          - paragraph [ref=e69]: "Responsável pelo desenvolvimento completo da solução: site, integração com o Notion, processamento de imagens, automação de publicação, testes e publicação na Cloudflare."
        - generic [ref=e70]:
          - heading "Decisões relevantes" [level=2] [ref=e71]
          - generic [ref=e72]:
            - article [ref=e73]:
              - heading "Site estático com conteúdo preparado no build" [level=3] [ref=e74]
              - paragraph [ref=e75]: As páginas são geradas com Astro a partir de modelos de conteúdo validados. O visitante recebe arquivos estáticos, sem depender de consultas ao Notion para montar o catálogo nem receber suas credenciais.
            - article [ref=e76]:
              - heading "Notion como painel editorial" [level=3] [ref=e77]
              - paragraph [ref=e78]: O conteúdo é mantido no Notion para permitir edição pelo celular. Uma interface TypeScript separa a apresentação da origem dos dados e permite usar fixtures nos testes sem acessar o painel real.
            - article [ref=e79]:
              - heading "Automação separada do site" [level=3] [ref=e80]
              - paragraph [ref=e81]: Um Cloudflare Worker agendado compara a assinatura do conteúdo com o manifesto publicado e solicita um build quando há diferença. O estado técnico fica em KV, separando a detecção de alterações da entrega das páginas ao visitante.
            - article [ref=e82]:
              - heading "Imagens derivadas com cache de build" [level=3] [ref=e83]
              - paragraph [ref=e84]: O pipeline com Sharp gera e reutiliza versões das imagens para a publicação estática. Apenas os derivados registrados no build são copiados para a saída, mantendo os originais e o cache fora dos arquivos públicos.
        - generic [ref=e85]:
          - heading "Stack" [level=2] [ref=e86]
          - list [ref=e87]:
            - listitem [ref=e88]: Astro
            - listitem [ref=e89]: TypeScript
            - listitem [ref=e90]: CSS puro
            - listitem [ref=e91]: Node.js
            - listitem [ref=e92]: Notion API
            - listitem [ref=e93]: Sharp
            - listitem [ref=e94]: Cloudflare Pages
            - listitem [ref=e95]: Cloudflare Workers e KV
            - listitem [ref=e96]: Vitest
            - listitem [ref=e97]: Playwright e axe-core
            - listitem [ref=e98]: GitHub Actions
        - generic [ref=e99]:
          - heading "Limitações conhecidas" [level=2] [ref=e100]
          - list [ref=e101]:
            - listitem [ref=e102]: O WhatsApp concentra atendimento e negociação; o site não confirma reservas nem processa pagamentos.
            - listitem [ref=e103]: Alterações editoriais dependem de um novo build para aparecer no site público.
            - listitem [ref=e104]: Retirar uma foto do próximo build não comprova sua remoção de caches e publicações anteriores; essa retirada exige verificação operacional.
            - listitem [ref=e105]: O ambiente publicado é de validação; os testes reais de dispositivos, desempenho, recuperação e capacidade ainda precisam ser concluídos.
        - generic [ref=e106]:
          - heading "Próximos passos" [level=2] [ref=e107]
          - list [ref=e108]:
            - listitem [ref=e109]: Concluir as verificações reais de navegação, WhatsApp, acessibilidade e desempenho com o conteúdo final.
            - listitem [ref=e110]: Validar a retirada de fotos nos URLs antigos e os procedimentos de recuperação da publicação.
            - listitem [ref=e111]: Verificar a consistência entre o conteúdo das páginas e o manifesto quando há edição durante o build.
      - generic [ref=e112]:
        - generic [ref=e113]:
          - link "← Todas as fichas" [ref=e114] [cursor=pointer]:
            - /url: /projetos
          - generic [ref=e115]:
            - generic [ref=e116]: Ficha 1 de 2
            - generic [ref=e117]: 1 / 2
        - navigation "Navegação entre fichas de projeto" [ref=e118]:
          - link "Próxima ficha → Plataforma de Portfólio" [ref=e119] [cursor=pointer]:
            - /url: /projetos/plataforma-portfolio
            - generic [ref=e120]: Próxima ficha →
            - strong [ref=e121]: Plataforma de Portfólio
        - region [ref=e122]:
          - generic [ref=e123]:
            - heading "Continue pelo currículo" [level=2] [ref=e124]
            - paragraph [ref=e125]: Veja o resumo profissional, as competências técnicas e os perfis em uma visão consolidada.
          - link "Ver currículo" [ref=e126] [cursor=pointer]:
            - /url: /curriculo
  - contentinfo [ref=e127]:
    - generic [ref=e128]:
      - navigation "Links secundários" [ref=e129]:
        - link "Início" [ref=e130] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=e131] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap" [ref=e132] [cursor=pointer]:
          - /url: /roadmap
        - link "Sobre" [ref=e133] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo" [ref=e134] [cursor=pointer]:
          - /url: /curriculo
      - region [ref=e135]:
        - heading "Vamos conversar." [level=2] [ref=e136]
        - paragraph [ref=e137]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=e138]:
          - link "Enviar e-mail" [ref=e139] [cursor=pointer]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=e140] [cursor=pointer]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=e141] [cursor=pointer]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=e142]: © 2026 Jefferson Nunes. Todos os direitos reservados.
  - alert [ref=e143]: Nana Silva | Portfólio
```

# Test source

```ts
  1   | import { test, expect, type Browser, type Page, type Request } from "@playwright/test";
  2   | 
  3   | // F1 (AUD03): depois de navegar por fragmento, Voltar/Avançar precisam manter
  4   | // URL e conteúdo coerentes. Cada passo compara título, h1 e item atual da
  5   | // navegação com os da mesma rota aberta diretamente.
  6   | 
  7   | type Referencia = { titulo: string; h1: string; navAtual: string | null };
  8   | const referencias = new Map<string, Referencia>();
  9   | 
  10  | async function referencia(browser: Browser, rota: string): Promise<Referencia> {
  11  |   const salva = referencias.get(rota);
  12  |   if (salva) return salva;
  13  |   const page = await browser.newPage();
  14  |   await page.goto(rota);
  15  |   const atual = page
  16  |     .getByRole("navigation", { name: "Navegação principal" })
  17  |     .locator('[aria-current="page"]');
  18  |   const nova = {
  19  |     titulo: await page.title(),
  20  |     h1: ((await page.locator("h1").textContent()) ?? "").replace(/\s+/g, " ").trim(),
  21  |     navAtual: (await atual.count()) ? await atual.getAttribute("href") : null,
  22  |   };
  23  |   await page.close();
  24  |   referencias.set(rota, nova);
  25  |   return nova;
  26  | }
  27  | 
  28  | async function esperarRota(page: Page, browser: Browser, url: string) {
  29  |   const [rota, fragmento] = url.split("#");
  30  |   const ref = await referencia(browser, rota);
  31  |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  32  |   await expect(page.locator("h1")).toHaveText(ref.h1);
  33  |   await expect(page).toHaveTitle(ref.titulo);
  34  |   const atual = page
  35  |     .getByRole("navigation", { name: "Navegação principal" })
  36  |     .locator('[aria-current="page"]');
  37  |   if (ref.navAtual) await expect(atual).toHaveAttribute("href", ref.navAtual);
  38  |   else await expect(atual).toHaveCount(0);
  39  |   // Ao voltar de outra rota, só o Chromium atualizou `:target` nas execuções da
  40  |   // AUD03; Firefox e WebKit do Playwright o deixaram nulo, e o Voltar comum do
  41  |   // App Router também não restaura a rolagem nesses casos. O projeto não usa
  42  |   // `:target` em CSS, então a coerência é verificada por URL e conteúdo.
  43  |   if (fragmento && browser.browserType().name() === "chromium") {
  44  |     await expect
  45  |       .poll(() => page.evaluate(() => document.querySelector(":target")?.id))
> 46  |       .toBe(fragmento);
      |        ^ Error: expect(received).toBe(expected) // Object.is equality
  47  |   }
  48  | }
  49  | 
  50  | async function hidratar(page: Page) {
  51  |   await page.waitForFunction(() => {
  52  |     const marca = document.querySelector("header a");
  53  |     return (
  54  |       !!marca &&
  55  |       Object.keys(marca).some((k) => k.startsWith("__reactFiber")) &&
  56  |       history.state !== null
  57  |     );
  58  |   });
  59  | }
  60  | 
  61  | async function abrir(page: Page, rota: string) {
  62  |   await page.goto(rota);
  63  |   await hidratar(page);
  64  | }
  65  | 
  66  | async function pularParaConteudo(page: Page) {
  67  |   await page.keyboard.press("Tab");
  68  |   await expect(page.locator("a.skip-link")).toBeFocused();
  69  |   await page.keyboard.press("Enter");
  70  |   await expect(page.locator("main#main-content")).toBeFocused();
  71  | }
  72  | 
  73  | // Aciona o skip link no HTML pré-renderizado, com os chunks retidos: a entrada
  74  | // de "/" fica sem estado. Devolve a função que libera os chunks.
  75  | async function pularAntesDaHidratacao(page: Page, rota = "/") {
  76  |   let liberar!: () => void;
  77  |   let retidos = 0;
  78  |   const portao = new Promise<void>((resolve) => (liberar = resolve));
  79  |   await page.route("**/_next/static/**/chunks/*.js", async (rota) => {
  80  |     retidos++;
  81  |     await portao;
  82  |     await rota.continue();
  83  |   });
  84  |   await page.goto(rota, { waitUntil: "domcontentloaded" });
  85  |   await pularParaConteudo(page);
  86  |   // Garante que o skip link agiu de fato antes da hidratação.
  87  |   expect(retidos).toBeGreaterThan(0);
  88  |   expect(
  89  |     await page.evaluate(() => {
  90  |       const marca = document.querySelector("header a");
  91  |       return {
  92  |         hidratado: !!marca && Object.keys(marca).some((k) => k.startsWith("__reactFiber")),
  93  |         estado: history.state,
  94  |       };
  95  |     }),
  96  |   ).toEqual({ hidratado: false, estado: null });
  97  |   return liberar;
  98  | }
  99  | 
  100 | // Marca o documento para detectar recarga e coleta erros da página.
  101 | async function vigiar(page: Page) {
  102 |   const erros: string[] = [];
  103 |   page.on("pageerror", (erro) => erros.push(String(erro)));
  104 |   page.on("console", (msg) => {
  105 |     if (msg.type() === "error") erros.push(msg.text());
  106 |   });
  107 |   await page.evaluate(() => {
  108 |     (window as Window & { __documento?: string }).__documento = "inicial";
  109 |   });
  110 |   return async () => {
  111 |     expect(
  112 |       await page.evaluate(() => (window as Window & { __documento?: string }).__documento),
  113 |     ).toBe("inicial");
  114 |     expect(erros).toEqual([]);
  115 |   };
  116 | }
  117 | 
  118 | // Diagnóstico (sem asserção): rota da árvore que o App Router gravou na entrada
  119 | // corrente. É campo interno do Next.js, por isso fica fora das verificações.
  120 | async function anotarArvore(page: Page, momento: string) {
  121 |   const rota = await page.evaluate(() => {
  122 |     type No = [string | [string, string, string], Record<string, No>];
  123 |     let no = (history.state as { __PRIVATE_NEXTJS_INTERNALS_TREE?: { tree?: No } } | null)
  124 |       ?.__PRIVATE_NEXTJS_INTERNALS_TREE?.tree;
  125 |     if (!no) return history.state === null ? "estado nulo" : "sem árvore";
  126 |     const segmentos: string[] = [];
  127 |     while (no) {
  128 |       const segmento = Array.isArray(no[0]) ? no[0][1] : no[0];
  129 |       if (segmento && !segmento.startsWith("__PAGE__")) segmentos.push(segmento);
  130 |       no = no[1]?.children;
  131 |     }
  132 |     return "/" + segmentos.join("/");
  133 |   });
  134 |   test.info().annotations.push({ type: `árvore gravada (${momento})`, description: rota });
  135 | }
  136 | 
  137 | const navegar = (page: Page, rotulo: string) =>
  138 |   page
  139 |     .getByRole("navigation", { name: "Navegação principal" })
  140 |     .getByRole("link", { name: rotulo, exact: true })
  141 |     .click();
  142 | 
  143 | test("F1 - skip link: Voltar e Avançar mantêm URL e conteúdo coerentes", async ({
  144 |   page,
  145 |   browser,
  146 | }) => {
```