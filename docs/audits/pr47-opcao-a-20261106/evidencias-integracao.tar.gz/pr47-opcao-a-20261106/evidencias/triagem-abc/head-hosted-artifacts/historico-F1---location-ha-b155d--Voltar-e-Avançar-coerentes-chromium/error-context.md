# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico.spec.ts >> F1 - location.hash e barra de endereço: Voltar e Avançar coerentes
- Location: triage-abc-tests/historico.spec.ts:515:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "projects-title"
Received: undefined

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Pular para o conteúdo principal" [ref=e2] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e3]:
    - generic [ref=e4]:
      - link "Jefferson Nunes — Início" [ref=e5] [cursor=pointer]:
        - /url: /
        - generic [ref=e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=e7]:
        - link "Início" [ref=e8] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=e10] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=e12] [cursor=pointer]:
          - /url: /roadmap
          - generic [ref=e13]: Roadmap
        - link "Sobre" [active] [ref=e14] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=e16] [cursor=pointer]:
          - /url: /curriculo
          - generic [ref=e17]: Currículo
  - main [ref=e18]:
    - region [ref=e19]:
      - generic [ref=e20]:
        - heading "Jefferson Nunes" [level=1] [ref=e21]:
          - text: Jefferson
          - generic [ref=e22]: Nunes.
        - paragraph [ref=e23]: Desenvolvedor Web em Formação
        - paragraph [ref=e24]: "Em formação, com interesse em desenvolvimento backend. O que apresento como trabalho implementado inclui esta plataforma: conteúdo validado em tempo de build, testes automatizados, acessibilidade verificada e integração contínua. O caminho para backend com Python e Django está registrado como escopo planejado, não como entrega."
        - generic [ref=e25]:
          - link "Ver projetos em destaque" [ref=e26] [cursor=pointer]:
            - /url: "#projects-title"
          - link "Ver currículo" [ref=e27] [cursor=pointer]:
            - /url: /curriculo
      - region [ref=e28]:
        - heading "Competências comprovadas nesta plataforma" [level=2] [ref=e29]
        - generic [ref=e30]:
          - generic [ref=e31]:
            - heading "Front-end" [level=3] [ref=e32]
            - list [ref=e33]:
              - listitem [ref=e34]: TypeScript
              - listitem [ref=e35]: React
              - listitem [ref=e36]: Next.js
              - listitem [ref=e37]: CSS sem framework
          - generic [ref=e38]:
            - heading "Engenharia de Software" [level=3] [ref=e39]
            - list [ref=e40]:
              - listitem [ref=e41]: Arquitetura modular
              - listitem [ref=e42]: Validação de dados em build
              - listitem [ref=e43]: Design de sistemas
              - listitem [ref=e44]: Versionamento com Git
          - generic [ref=e45]:
            - heading "Qualidade" [level=3] [ref=e46]
            - list [ref=e47]:
              - listitem [ref=e48]: Testes automatizados
              - listitem [ref=e49]: Testes end-to-end
              - listitem [ref=e50]: Acessibilidade WCAG 2.1 AA
          - generic [ref=e51]:
            - heading "Operação" [level=3] [ref=e52]
            - list [ref=e53]:
              - listitem [ref=e54]: Node.js
              - listitem [ref=e55]: CI/CD
        - paragraph [ref=e56]:
          - text: Tecnologias de backend e cloud, como Python, Django, Docker e Google Cloud Platform, aparecem apenas como estudo no
          - link "roadmap de estudos" [ref=e57] [cursor=pointer]:
            - /url: /roadmap
          - text: ; não são competências declaradas nesta ficha.
    - region [ref=e58]:
      - generic [ref=e59]:
        - heading "Trabalho em prática." [level=2] [ref=e60]
        - paragraph [ref=e61]:
          - text: 2 projetos implementados, com suas decisões e limitações.
          - link "Ver todas as fichas" [ref=e62] [cursor=pointer]:
            - /url: /projetos
      - generic [ref=e63]:
        - article [ref=e64]:
          - generic [ref=e65]:
            - generic [ref=e66]:
              - group "Classificação do projeto" [ref=e67]:
                - generic [ref=e68]: Em andamento
                - generic [ref=e69]: Web
                - generic [ref=e70]: Profissional
                - generic [ref=e71]: Em validação
              - heading "Nana Silva" [level=3] [ref=e72]
              - paragraph [ref=e74]: Portfólio-catálogo de tatuagens com Astro, conteúdo editado no Notion e contato pelo WhatsApp, publicado na Cloudflare.
              - paragraph [ref=e75]:
                - strong [ref=e76]: "Problema:"
                - text: Reunir desenhos de tatuagem e sua disponibilidade em um catálogo que a artista possa atualizar pelo celular, sem editar código, encaminhando os interessados ao WhatsApp.
            - generic [ref=e77]:
              - generic [ref=e78]:
                - link "Ver detalhes de Nana Silva" [ref=e79] [cursor=pointer]:
                  - /url: /projetos/nana-silva
                - link "Ver demonstração" [ref=e80] [cursor=pointer]:
                  - /url: https://nana-silva-validacao.pages.dev/
                - generic [ref=e81]: Código privado
                - link "Solicitar acesso ao código" [ref=e82] [cursor=pointer]:
                  - /url: mailto:jeffnunesxavier@gmail.com?subject=Acesso ao código do projeto
              - list "Tecnologias de Nana Silva" [ref=e83]:
                - listitem [ref=e84]: Astro
                - listitem [ref=e85]: TypeScript
                - listitem [ref=e86]: Notion
                - listitem [ref=e87]: Cloudflare Workers
              - generic [ref=e88]:
                - paragraph [ref=e89]: "Competências:"
                - generic [ref=e90]:
                  - generic [ref=e91]:
                    - term [ref=e92]: Front-end
                    - definition [ref=e93]: TypeScript, CSS sem framework
                  - generic [ref=e94]:
                    - term [ref=e95]: Engenharia de Software
                    - definition [ref=e96]: Arquitetura modular, Validação de dados em build, Versionamento com Git
                  - generic [ref=e97]:
                    - term [ref=e98]: Qualidade
                    - definition [ref=e99]: Testes automatizados, Testes end-to-end
                  - generic [ref=e100]:
                    - term [ref=e101]: Operação
                    - definition [ref=e102]: Node.js, CI/CD
            - group [ref=e103]:
              - generic "Escolhas e limites de Nana Silva" [ref=e104] [cursor=pointer]
        - article [ref=e105]:
          - figure [ref=e106]:
            - generic [ref=e107]:
              - link "Ler descrição de Plataforma de Portfólio" [ref=e108] [cursor=pointer]:
                - /url: /projetos/plataforma-portfolio#contexto
              - paragraph [ref=e109]: Prévia ilustrativa. Se a prévia não aparecer, a descrição do projeto continua disponível.
          - generic [ref=e111]:
            - generic [ref=e112]:
              - group "Classificação do projeto" [ref=e113]:
                - generic [ref=e114]: Em andamento
                - generic [ref=e115]: Web
                - generic [ref=e116]: Autoral
              - heading "Plataforma de Portfólio" [level=3] [ref=e117]
              - paragraph [ref=e119]: Portfólio pessoal construído com Next.js para apresentar projetos e trajetória profissional de forma estruturada.
              - paragraph [ref=e120]:
                - strong [ref=e121]: "Problema:"
                - text: Falta de um canal único e versionado para apresentar projetos, competências e trajetória a recrutadores e clientes.
            - generic [ref=e122]:
              - generic [ref=e123]:
                - link "Ver detalhes de Plataforma de Portfólio" [ref=e124] [cursor=pointer]:
                  - /url: /projetos/plataforma-portfolio
                - generic [ref=e125]: Código privado
                - link "Solicitar acesso ao código" [ref=e126] [cursor=pointer]:
                  - /url: mailto:jeffnunesxavier@gmail.com?subject=Acesso ao código do projeto
              - list "Tecnologias de Plataforma de Portfólio" [ref=e127]:
                - listitem [ref=e128]: Next.js
                - listitem [ref=e129]: TypeScript
                - listitem [ref=e130]: React
              - generic [ref=e131]:
                - paragraph [ref=e132]: "Competências:"
                - generic [ref=e133]:
                  - generic [ref=e134]:
                    - term [ref=e135]: Front-end
                    - definition [ref=e136]: TypeScript, React, Next.js, CSS sem framework
                  - generic [ref=e137]:
                    - term [ref=e138]: Engenharia de Software
                    - definition [ref=e139]: Arquitetura modular, Validação de dados em build, Design de sistemas, Versionamento com Git
                  - generic [ref=e140]:
                    - term [ref=e141]: Qualidade
                    - definition [ref=e142]: Testes automatizados, Testes end-to-end, Acessibilidade WCAG 2.1 AA
                  - generic [ref=e143]:
                    - term [ref=e144]: Operação
                    - definition [ref=e145]: Node.js, CI/CD
            - group [ref=e146]:
              - generic "Escolhas e limites de Plataforma de Portfólio" [ref=e147] [cursor=pointer]
    - region [ref=e148]:
      - generic [ref=e149]:
        - heading "Da fonte à página." [level=2] [ref=e150]
        - paragraph [ref=e151]: Testes E2E com Playwright e verificações WCAG 2.1 A/AA com axe-core, executados separadamente na integração contínua.
      - generic [ref=e152]:
        - figure "O caminho do conteúdo até a página. Esquema simplificado do build." [ref=e153]:
          - list "Etapas do fluxo de publicação" [ref=e154]:
            - listitem [ref=e155]:
              - strong [ref=e158]: Conteúdo
              - generic [ref=e159]: JSON versionado
            - listitem [ref=e162]:
              - strong [ref=e165]: Validação
              - generic [ref=e166]: Campos e evidências
            - listitem [ref=e169]:
              - strong [ref=e172]: Publicação
              - generic [ref=e173]: Páginas estáticas
        - group [ref=e175]:
          - generic "Ver comprovação" [ref=e176] [cursor=pointer]
      - generic [ref=e177]:
        - heading "Integração contínua desta plataforma" [level=3] [ref=e178]
        - list "Etapas da integração contínua, em ordem" [ref=e179]:
          - listitem [ref=e180]: audit
          - listitem [ref=e181]: format
          - listitem [ref=e182]: lint
          - listitem [ref=e183]: typecheck
          - listitem [ref=e184]: vitest
          - listitem [ref=e185]: build
          - listitem [ref=e186]: e2e
          - listitem [ref=e187]: axe
        - paragraph [ref=e188]:
          - text: Ordem configurada em
          - code [ref=e189]: .github/workflows/ci.yml
          - text: . Este registro descreve o fluxo; não representa uma execução ao vivo.
    - region [ref=e190]:
      - generic [ref=e191]:
        - heading "Caminho em construção." [level=2] [ref=e192]
        - paragraph [ref=e193]: Escopo planejado de estudo. Nada aqui existe como código; por isso fica separado dos projetos implementados.
      - generic [ref=e194]:
        - paragraph [ref=e195]: 4 projetos registrados como escopo planejado.
        - link "Consultar o roadmap" [ref=e196] [cursor=pointer]:
          - /url: /roadmap
  - contentinfo [ref=e197]:
    - generic [ref=e198]:
      - navigation "Links secundários" [ref=e199]:
        - link "Início" [ref=e200] [cursor=pointer]:
          - /url: /
        - link "Projetos" [ref=e201] [cursor=pointer]:
          - /url: /projetos
        - link "Roadmap" [ref=e202] [cursor=pointer]:
          - /url: /roadmap
        - link "Sobre" [ref=e203] [cursor=pointer]:
          - /url: /sobre
        - link "Currículo" [ref=e204] [cursor=pointer]:
          - /url: /curriculo
      - region [ref=e205]:
        - heading "Vamos conversar." [level=2] [ref=e206]
        - paragraph [ref=e207]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=e208]:
          - link "Enviar e-mail" [ref=e209] [cursor=pointer]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=e210] [cursor=pointer]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=e211] [cursor=pointer]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=e212]: © 2026 Jefferson Nunes. Todos os direitos reservados.
  - alert [ref=e213]: Desenvolvedor Web em Formação
```

# Test source

```ts
  1   | import { test, expect, type Browser, type Page, type Request } from "@playwright/test";
  2   | 
  3   | // F1 (AUD03): depois de navegar por fragmento, Voltar/Avançar precisam manter
  4   | // URL e conteúdo coerentes. Cada passo compara título, h1 e item atual da
  5   | // navegação com os da mesma rota aberta diretamente.
  6   | 
  7   | type Referencia = { titulo: string; h1: string; navAtual: string | null };
  8   | const referencias = new Map<string, Referencia>();
  9   | 
  10  | async function referencia(browser: Browser, rota: string): Promise<Referencia> {
  11  |   const salva = referencias.get(rota);
  12  |   if (salva) return salva;
  13  |   const page = await browser.newPage();
  14  |   await page.goto(rota);
  15  |   const atual = page
  16  |     .getByRole("navigation", { name: "Navegação principal" })
  17  |     .locator('[aria-current="page"]');
  18  |   const nova = {
  19  |     titulo: await page.title(),
  20  |     h1: ((await page.locator("h1").textContent()) ?? "").replace(/\s+/g, " ").trim(),
  21  |     navAtual: (await atual.count()) ? await atual.getAttribute("href") : null,
  22  |   };
  23  |   await page.close();
  24  |   referencias.set(rota, nova);
  25  |   return nova;
  26  | }
  27  | 
  28  | async function esperarRota(page: Page, browser: Browser, url: string) {
  29  |   const [rota, fragmento] = url.split("#");
  30  |   const ref = await referencia(browser, rota);
  31  |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  32  |   await expect(page.locator("h1")).toHaveText(ref.h1);
  33  |   await expect(page).toHaveTitle(ref.titulo);
  34  |   const atual = page
  35  |     .getByRole("navigation", { name: "Navegação principal" })
  36  |     .locator('[aria-current="page"]');
  37  |   if (ref.navAtual) await expect(atual).toHaveAttribute("href", ref.navAtual);
  38  |   else await expect(atual).toHaveCount(0);
  39  |   // Ao voltar de outra rota, só o Chromium atualizou `:target` nas execuções da
  40  |   // AUD03; Firefox e WebKit do Playwright o deixaram nulo, e o Voltar comum do
  41  |   // App Router também não restaura a rolagem nesses casos. O projeto não usa
  42  |   // `:target` em CSS, então a coerência é verificada por URL e conteúdo.
  43  |   if (fragmento && browser.browserType().name() === "chromium") {
  44  |     await expect
  45  |       .poll(() => page.evaluate(() => document.querySelector(":target")?.id))
> 46  |       .toBe(fragmento);
      |        ^ Error: expect(received).toBe(expected) // Object.is equality
  47  |   }
  48  | }
  49  | 
  50  | async function hidratar(page: Page) {
  51  |   await page.waitForFunction(() => {
  52  |     const marca = document.querySelector("header a");
  53  |     return (
  54  |       !!marca &&
  55  |       Object.keys(marca).some((k) => k.startsWith("__reactFiber")) &&
  56  |       history.state !== null
  57  |     );
  58  |   });
  59  | }
  60  | 
  61  | async function abrir(page: Page, rota: string) {
  62  |   await page.goto(rota);
  63  |   await hidratar(page);
  64  | }
  65  | 
  66  | async function pularParaConteudo(page: Page) {
  67  |   await page.keyboard.press("Tab");
  68  |   await expect(page.locator("a.skip-link")).toBeFocused();
  69  |   await page.keyboard.press("Enter");
  70  |   await expect(page.locator("main#main-content")).toBeFocused();
  71  | }
  72  | 
  73  | // Aciona o skip link no HTML pré-renderizado, com os chunks retidos: a entrada
  74  | // de "/" fica sem estado. Devolve a função que libera os chunks.
  75  | async function pularAntesDaHidratacao(page: Page, rota = "/") {
  76  |   let liberar!: () => void;
  77  |   let retidos = 0;
  78  |   const portao = new Promise<void>((resolve) => (liberar = resolve));
  79  |   await page.route("**/_next/static/**/chunks/*.js", async (rota) => {
  80  |     retidos++;
  81  |     await portao;
  82  |     await rota.continue();
  83  |   });
  84  |   await page.goto(rota, { waitUntil: "domcontentloaded" });
  85  |   await pularParaConteudo(page);
  86  |   // Garante que o skip link agiu de fato antes da hidratação.
  87  |   expect(retidos).toBeGreaterThan(0);
  88  |   expect(
  89  |     await page.evaluate(() => {
  90  |       const marca = document.querySelector("header a");
  91  |       return {
  92  |         hidratado: !!marca && Object.keys(marca).some((k) => k.startsWith("__reactFiber")),
  93  |         estado: history.state,
  94  |       };
  95  |     }),
  96  |   ).toEqual({ hidratado: false, estado: null });
  97  |   return liberar;
  98  | }
  99  | 
  100 | // Marca o documento para detectar recarga e coleta erros da página.
  101 | async function vigiar(page: Page) {
  102 |   const erros: string[] = [];
  103 |   page.on("pageerror", (erro) => erros.push(String(erro)));
  104 |   page.on("console", (msg) => {
  105 |     if (msg.type() === "error") erros.push(msg.text());
  106 |   });
  107 |   await page.evaluate(() => {
  108 |     (window as Window & { __documento?: string }).__documento = "inicial";
  109 |   });
  110 |   return async () => {
  111 |     expect(
  112 |       await page.evaluate(() => (window as Window & { __documento?: string }).__documento),
  113 |     ).toBe("inicial");
  114 |     expect(erros).toEqual([]);
  115 |   };
  116 | }
  117 | 
  118 | // Diagnóstico (sem asserção): rota da árvore que o App Router gravou na entrada
  119 | // corrente. É campo interno do Next.js, por isso fica fora das verificações.
  120 | async function anotarArvore(page: Page, momento: string) {
  121 |   const rota = await page.evaluate(() => {
  122 |     type No = [string | [string, string, string], Record<string, No>];
  123 |     let no = (history.state as { __PRIVATE_NEXTJS_INTERNALS_TREE?: { tree?: No } } | null)
  124 |       ?.__PRIVATE_NEXTJS_INTERNALS_TREE?.tree;
  125 |     if (!no) return history.state === null ? "estado nulo" : "sem árvore";
  126 |     const segmentos: string[] = [];
  127 |     while (no) {
  128 |       const segmento = Array.isArray(no[0]) ? no[0][1] : no[0];
  129 |       if (segmento && !segmento.startsWith("__PAGE__")) segmentos.push(segmento);
  130 |       no = no[1]?.children;
  131 |     }
  132 |     return "/" + segmentos.join("/");
  133 |   });
  134 |   test.info().annotations.push({ type: `árvore gravada (${momento})`, description: rota });
  135 | }
  136 | 
  137 | const navegar = (page: Page, rotulo: string) =>
  138 |   page
  139 |     .getByRole("navigation", { name: "Navegação principal" })
  140 |     .getByRole("link", { name: rotulo, exact: true })
  141 |     .click();
  142 | 
  143 | test("F1 - skip link: Voltar e Avançar mantêm URL e conteúdo coerentes", async ({
  144 |   page,
  145 |   browser,
  146 | }) => {
```