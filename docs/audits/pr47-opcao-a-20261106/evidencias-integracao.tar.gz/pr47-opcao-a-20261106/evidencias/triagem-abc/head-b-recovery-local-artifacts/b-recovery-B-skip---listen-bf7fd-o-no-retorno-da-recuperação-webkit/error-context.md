# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: b-recovery.spec.ts >> B skip - listener atrasado no retorno da recuperação
- Location: triage-abc-tests/b-recovery.spec.ts:2:49

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('h1')
Expected: "Página não encontrada"
Received: "Projetos"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" with timeout 5000ms
  - waiting for locator('h1')
    14 × locator resolved to <h1 id="projects-title">Projetos</h1>
       - unexpected value "Projetos"

```

```yaml
- heading "Projetos" [level=1]
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | for(const momento of ['atrasado','pronto']) test(`B skip - listener ${momento} no retorno da recuperação`,async({page},info)=>{
  3  |  const events:unknown[]=[];await page.exposeFunction('triageEvent',(e:unknown)=>events.push(e));
  4  |  await page.addInitScript(()=>{
  5  |   const original=window.addEventListener;
  6  |   (window as any).__released=false;
  7  |   const pending:(()=>void)[]=[];
  8  |   (window as any).__release=()=>{(window as any).__released=true;for(const run of pending.splice(0))run();};
  9  |   window.addEventListener=function(type:any,listener:any,options:any){
  10 |    if(type==='popstate' && options===true && !(window as any).__released){
  11 |     pending.push(()=>{original.call(this,type,listener,options);(window as any).__captureReady=true;});
  12 |     (window as any).__captureHeld=true;return;
  13 |    }
  14 |    return original.call(this,type,listener,options);
  15 |   } as any;
  16 |   original.call(window,'popstate',(e:PopStateEvent)=>{(window as any).__popSeen=true;(window as any).triageEvent({url:location.href,ready:!!(window as any).__captureReady,trusted:e.isTrusted,stateNull:e.state===null,h1:document.querySelector('h1')?.textContent});});
  17 |  });
  18 |  try {
  19 |   await page.goto('/rota-inexistente#main-content');
  20 |   await page.waitForFunction(()=>{const a=document.querySelector('header a');return !!a && Object.keys(a).some(k=>k.startsWith('__reactFiber')) && history.state!==null;});
  21 |   await page.waitForFunction(()=>(window as any).__captureHeld);
  22 |   if(momento==='pronto')await page.evaluate(()=>(window as any).__release());
  23 |   await page.getByRole('navigation',{name:'Navegação principal'}).getByRole('link',{name:'Projetos',exact:true}).click();
  24 |   await expect(page.locator('h1')).toHaveText('Projetos');await expect(page).toHaveURL(/\/projetos$/);
  25 |   await page.goBack();
  26 |   await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
  27 |   if(momento==='atrasado'){
  28 |    await page.waitForFunction(()=>(window as any).__popSeen);
  29 |    await page.evaluate(()=>(window as any).__release());
  30 |   } else {
  31 |    await page.waitForFunction(()=>(window as any).__captureHeld);await page.evaluate(()=>(window as any).__release());
  32 |   }
> 33 |   await expect(page.locator('h1')).toHaveText('Página não encontrada');
     |                                    ^ Error: expect(locator).toHaveText(expected) failed
  34 |  } finally {await info.attach('events',{body:JSON.stringify(events),contentType:'application/json'});}
  35 | });
  36 | 
```