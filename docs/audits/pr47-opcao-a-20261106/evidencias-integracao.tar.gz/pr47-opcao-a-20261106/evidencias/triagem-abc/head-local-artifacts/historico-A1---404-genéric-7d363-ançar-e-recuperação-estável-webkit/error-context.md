# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico.spec.ts >> A1 - 404 genérica: skip, Voltar/Avançar e recuperação estável
- Location: triage-abc-tests/historico.spec.ts:235:7

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 3

- Array []
+ Array [
+   "/localhost:3101/projetos/nana-silva?_rsc=F7ufU-sfG9N3x5EV due to access control checks.",
+ ]
```

# Page snapshot

```yaml
- generic [ref=f4e1]:
  - link "Pular para o conteúdo principal" [ref=f4e2]:
    - /url: "#main-content"
  - banner [ref=f4e3]:
    - generic [ref=f4e4]:
      - link "Jefferson Nunes — Início" [ref=f4e5]:
        - /url: /
        - generic [ref=f4e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=f4e7]:
        - link "Início" [ref=f4e8]:
          - /url: /
        - link "Projetos" [ref=f4e10]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=f4e12]:
          - /url: /roadmap
          - generic [ref=f4e13]: Roadmap
        - link "Sobre" [ref=f4e14]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=f4e16]:
          - /url: /curriculo
          - generic [ref=f4e17]: Currículo
  - main [active] [ref=f4e18]:
    - generic [ref=f4e20]:
      - generic [ref=f4e21]:
        - heading "Página não encontrada" [level=1] [ref=f4e22]
        - paragraph [ref=f4e23]: HTTP 404 · Registro inexistente
        - paragraph [ref=f4e24]: A página que você procura não existe ou foi removida.
        - link "Voltar para a página inicial" [ref=f4e25]:
          - /url: /
        - link "Ver todos os projetos" [ref=f4e26]:
          - /url: /projetos
      - generic [ref=f4e27]:
        - generic [ref=f4e28]:
          - term [ref=f4e29]: Acervo publicado
          - definition [ref=f4e30]: 2 fichas
        - generic [ref=f4e31]:
          - term [ref=f4e32]: Escopo planejado
          - definition [ref=f4e33]: 4 entradas
        - generic [ref=f4e34]:
          - term [ref=f4e35]: Destino de retorno
          - definition [ref=f4e36]: Página inicial
  - contentinfo [ref=f4e37]:
    - generic [ref=f4e38]:
      - navigation "Links secundários" [ref=f4e39]:
        - link "Início" [ref=f4e40]:
          - /url: /
        - link "Projetos" [ref=f4e41]:
          - /url: /projetos
        - link "Roadmap" [ref=f4e42]:
          - /url: /roadmap
        - link "Sobre" [ref=f4e43]:
          - /url: /sobre
        - link "Currículo" [ref=f4e44]:
          - /url: /curriculo
      - region [ref=f4e45]:
        - heading "Vamos conversar." [level=2] [ref=f4e46]
        - paragraph [ref=f4e47]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=f4e48]:
          - link "Enviar e-mail" [ref=f4e49]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=f4e50]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=f4e51]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=f4e52]: © 2026 Jefferson Nunes. Todos os direitos reservados.
  - alert [ref=f4e53]
```

# Test source

```ts
  122 |     type No = [string | [string, string, string], Record<string, No>];
  123 |     let no = (history.state as { __PRIVATE_NEXTJS_INTERNALS_TREE?: { tree?: No } } | null)
  124 |       ?.__PRIVATE_NEXTJS_INTERNALS_TREE?.tree;
  125 |     if (!no) return history.state === null ? "estado nulo" : "sem árvore";
  126 |     const segmentos: string[] = [];
  127 |     while (no) {
  128 |       const segmento = Array.isArray(no[0]) ? no[0][1] : no[0];
  129 |       if (segmento && !segmento.startsWith("__PAGE__")) segmentos.push(segmento);
  130 |       no = no[1]?.children;
  131 |     }
  132 |     return "/" + segmentos.join("/");
  133 |   });
  134 |   test.info().annotations.push({ type: `árvore gravada (${momento})`, description: rota });
  135 | }
  136 | 
  137 | const navegar = (page: Page, rotulo: string) =>
  138 |   page
  139 |     .getByRole("navigation", { name: "Navegação principal" })
  140 |     .getByRole("link", { name: rotulo, exact: true })
  141 |     .click();
  142 | 
  143 | test("F1 - skip link: Voltar e Avançar mantêm URL e conteúdo coerentes", async ({
  144 |   page,
  145 |   browser,
  146 | }) => {
  147 |   await abrir(page, "/");
  148 |   await pularParaConteudo(page);
  149 |   await navegar(page, "Sobre");
  150 |   await esperarRota(page, browser, "/sobre");
  151 | 
  152 |   await page.goBack();
  153 |   await esperarRota(page, browser, "/#main-content");
  154 |   await page.goForward();
  155 |   await esperarRota(page, browser, "/sobre");
  156 |   await page.goBack();
  157 |   await page.goBack();
  158 |   await esperarRota(page, browser, "/");
  159 | });
  160 | 
  161 | // A1: a 404 genérica usa o fallback de documento do Next. A recuperação deve
  162 | // distinguir entradas nulas e não nulas sem recarregar fragmentos na própria
  163 | // 404 nem substituir a F1 nas rotas válidas.
  164 | async function esperar404Generica(page: Page, url: string) {
  165 |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  166 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  167 |   await expect(page).toHaveTitle("Página não encontrada | Portfólio");
  168 |   await expect(page.locator("main")).toContainText("A página que você procura não existe");
  169 |   await expect(
  170 |     page.getByRole("navigation", { name: "Navegação principal" }).locator("[aria-current]"),
  171 |   ).toHaveCount(0);
  172 |   await hidratar(page);
  173 | }
  174 | 
  175 | async function observarA1(page: Page) {
  176 |   const documentos: { url: string; status: number }[] = [];
  177 |   const requisicoesRsc: string[] = [];
  178 |   const eventos: unknown[] = [];
  179 |   const erros: string[] = [];
  180 |   page.on("response", (resposta) => {
  181 |     if (resposta.request().resourceType() === "document") {
  182 |       documentos.push({ url: resposta.url(), status: resposta.status() });
  183 |     }
  184 |   });
  185 |   page.on("pageerror", (erro) => erros.push(erro.message));
  186 |   page.on("request", (requisicao) => {
  187 |     if (requisicao.headers()["rsc"]) requisicoesRsc.push(requisicao.url());
  188 |   });
  189 |   // O router às vezes aborta a leitura do corpo da RSC já respondida: conta as
  190 |   // requisições encerradas, com ou sem falha.
  191 |   const rscEncerradas: string[] = [];
  192 |   const encerrarRsc = (requisicao: Request) => {
  193 |     if (requisicao.headers()["rsc"]) rscEncerradas.push(new URL(requisicao.url()).pathname);
  194 |   };
  195 |   page.on("requestfinished", encerrarRsc);
  196 |   page.on("requestfailed", encerrarRsc);
  197 |   await page.exposeFunction("registrarHistoricoA1", (evento: unknown) => eventos.push(evento));
  198 |   await page.addInitScript(() => {
  199 |     const janela = window as unknown as Window & {
  200 |       documentoA1?: string;
  201 |       registrarHistoricoA1: (evento: unknown) => Promise<void>;
  202 |     };
  203 |     janela.documentoA1 = crypto.randomUUID();
  204 |     window.addEventListener("popstate", (evento) => {
  205 |       void janela.registrarHistoricoA1({
  206 |         url: location.href,
  207 |         estado: evento.state,
  208 |         titulo: document.title,
  209 |         h1: document.querySelector("h1")?.textContent,
  210 |       });
  211 |     });
  212 |   });
  213 |   const documento = () =>
  214 |     page.evaluate(() => (window as Window & { documentoA1?: string }).documentoA1);
  215 |   const conferirEstabilidade = async () => {
  216 |     await page.waitForLoadState("networkidle");
  217 |     const quantidade = documentos.length;
  218 |     const quantidadeRsc = requisicoesRsc.length;
  219 |     await page.waitForTimeout(700);
  220 |     expect(documentos).toHaveLength(quantidade);
  221 |     expect(requisicoesRsc).toHaveLength(quantidadeRsc);
> 222 |     expect(erros).toEqual([]);
      |                   ^ Error: expect(received).toEqual(expected) // deep equality
  223 |   };
  224 |   const registrar = async () => {
  225 |     await test.info().attach("historico-a1", {
  226 |       body: JSON.stringify({ documentos, requisicoesRsc, eventos, erros }, null, 2),
  227 |       contentType: "application/json",
  228 |     });
  229 |   };
  230 |   const rscEncerradasDe = (rota: string) => rscEncerradas.filter((p) => p === rota).length;
  231 |   return { documentos, documento, conferirEstabilidade, registrar, rscEncerradasDe };
  232 | }
  233 | 
  234 | for (const entrada of ["skip", "hash direto", "location.hash", "pré-hidratação"] as const) {
  235 |   test(`A1 - 404 genérica: ${entrada}, Voltar/Avançar e recuperação estável`, async ({ page }) => {
  236 |     const observacao = await observarA1(page);
  237 |     const rota = "/rota-inexistente";
  238 |     const url = rota + "#main-content";
  239 |     if (entrada === "pré-hidratação") {
  240 |       const liberar = await pularAntesDaHidratacao(page, rota);
  241 |       liberar();
  242 |       await hidratar(page);
  243 |     } else {
  244 |       await abrir(page, entrada === "hash direto" ? url : rota);
  245 |       if (entrada === "skip") await pularParaConteudo(page);
  246 |       if (entrada === "location.hash") {
  247 |         await page.evaluate(() => {
  248 |           location.hash = "main-content";
  249 |         });
  250 |         await expect(page.locator("main")).toBeFocused();
  251 |       }
  252 |     }
  253 |     await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  254 |     // #45: o estado restaurado pelo Next pertence à 404 confirmada.
  255 |     await expect.poll(() => page.evaluate(() => history.state !== null)).toBe(true);
  256 |     const inicial = await observacao.documento();
  257 |     const entradas = await page.evaluate(() => history.length);
  258 |     await observacao.conferirEstabilidade();
  259 |     expect(observacao.documentos).toHaveLength(1);
  260 |     expect(observacao.documentos[0].status).toBe(404);
  261 | 
  262 |     await page
  263 |       .getByRole("navigation", { name: "Navegação principal" })
  264 |       .getByRole("link", { name: "Sobre", exact: true })
  265 |       .focus();
  266 |     await page.keyboard.press("Enter");
  267 |     await expect(page.locator("h1")).toHaveText("Sobre");
  268 |     await expect(page).toHaveTitle("Sobre | Portfólio");
  269 |     expect(await observacao.documento()).toBe(inicial);
  270 | 
  271 |     await page.goBack();
  272 |     await esperar404Generica(page, url);
  273 |     expect(await observacao.documento()).not.toBe(inicial);
  274 |     expect(await page.evaluate(() => history.length)).toBe(entradas + 1);
  275 |     expect(observacao.documentos).toHaveLength(2);
  276 |     expect(observacao.documentos[1].status).toBe(404);
  277 |     // A recarga pode restaurar BODY (histórico salvo antes da hidratação) ou
  278 |     // MAIN (abertura do hash), como nos controles nativos da mesma 404.
  279 |     const foco = await page.evaluate(() => ({
  280 |       tag: document.activeElement?.tagName,
  281 |       id: document.activeElement?.id,
  282 |     }));
  283 |     expect([
  284 |       { tag: "MAIN", id: "main-content" },
  285 |       { tag: "BODY", id: "" },
  286 |     ]).toContainEqual(foco);
  287 |     // #45: restaurar a 404 confirmada não pede RSC nem repete o fragmento.
  288 |     const rscAntesDoSkip = observacao.rscEncerradasDe(rota);
  289 |     await pularParaConteudoFocado(page);
  290 |     await page.keyboard.press("Tab");
  291 |     const voltarParaInicio = page.getByRole("link", { name: "Voltar para a página inicial" });
  292 |     await expect(voltarParaInicio).toBeFocused();
  293 |     await observacao.conferirEstabilidade();
  294 |     await expect(voltarParaInicio).toBeFocused();
  295 |     expect(observacao.rscEncerradasDe(rota)).toBe(rscAntesDoSkip);
  296 | 
  297 |     await page.goForward();
  298 |     await expect(page).toHaveURL(/\/sobre$/);
  299 |     await expect(page.locator("h1")).toHaveText("Sobre");
  300 |     await page.goBack();
  301 |     await esperar404Generica(page, url);
  302 |     await observacao.conferirEstabilidade();
  303 |     expect(await page.evaluate(() => history.length)).toBe(entradas + 1);
  304 |     const resposta = await page.reload();
  305 |     expect(resposta?.status()).toBe(404);
  306 |     await esperar404Generica(page, url);
  307 |     await navegar(page, "Projetos");
  308 |     await expect(page.locator("h1")).toHaveText("Projetos");
  309 |     await page.goBack();
  310 |     await esperar404Generica(page, url);
  311 |     await observacao.conferirEstabilidade();
  312 |     await observacao.registrar();
  313 |   });
  314 | }
  315 | 
  316 | test("A1 - fragmentos na própria 404 são nativos e não recarregam", async ({ page }) => {
  317 |   const observacao = await observarA1(page);
  318 |   await abrir(page, "/rota-inexistente");
  319 |   const inicial = await observacao.documento();
  320 |   await pularParaConteudo(page);
  321 |   await page.evaluate(() => {
  322 |     location.hash = "outro-fragmento";
```