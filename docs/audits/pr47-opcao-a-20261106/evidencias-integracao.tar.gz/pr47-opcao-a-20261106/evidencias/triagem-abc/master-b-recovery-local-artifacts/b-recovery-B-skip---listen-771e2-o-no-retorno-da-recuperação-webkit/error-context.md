# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: b-recovery.spec.ts >> B skip - listener pronto no retorno da recuperação
- Location: triage-abc-tests/b-recovery.spec.ts:2:49

# Error details

```
Error: page.evaluate: Execution context was destroyed, most likely because of a navigation
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - link "Pular para o conteúdo principal" [ref=f1e2]:
    - /url: "#main-content"
  - banner [ref=f1e3]:
    - generic [ref=f1e4]:
      - link "Jefferson Nunes — Início" [ref=f1e5]:
        - /url: /
        - generic [ref=f1e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=f1e7]:
        - link "Início" [ref=f1e8]:
          - /url: /
        - link "Projetos" [ref=f1e10]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=f1e12]:
          - /url: /roadmap
          - generic [ref=f1e13]: Roadmap
        - link "Sobre" [ref=f1e14]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=f1e16]:
          - /url: /curriculo
          - generic [ref=f1e17]: Currículo
  - main [active] [ref=f1e18]:
    - generic [ref=f1e20]:
      - generic [ref=f1e21]:
        - heading "Página não encontrada" [level=1] [ref=f1e22]
        - paragraph [ref=f1e23]: HTTP 404 · Registro inexistente
        - paragraph [ref=f1e24]: A página que você procura não existe ou foi removida.
        - link "Voltar para a página inicial" [ref=f1e25]:
          - /url: /
        - link "Ver todos os projetos" [ref=f1e26]:
          - /url: /projetos
      - generic [ref=f1e27]:
        - generic [ref=f1e28]:
          - term [ref=f1e29]: Acervo publicado
          - definition [ref=f1e30]: 2 fichas
        - generic [ref=f1e31]:
          - term [ref=f1e32]: Escopo planejado
          - definition [ref=f1e33]: 4 entradas
        - generic [ref=f1e34]:
          - term [ref=f1e35]: Destino de retorno
          - definition [ref=f1e36]: Página inicial
  - contentinfo [ref=f1e37]:
    - generic [ref=f1e38]:
      - navigation "Links secundários" [ref=f1e39]:
        - link "Início" [ref=f1e40]:
          - /url: /
        - link "Projetos" [ref=f1e41]:
          - /url: /projetos
        - link "Roadmap" [ref=f1e42]:
          - /url: /roadmap
        - link "Sobre" [ref=f1e43]:
          - /url: /sobre
        - link "Currículo" [ref=f1e44]:
          - /url: /curriculo
      - region [ref=f1e45]:
        - heading "Vamos conversar." [level=2] [ref=f1e46]
        - paragraph [ref=f1e47]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=f1e48]:
          - link "Enviar e-mail" [ref=f1e49]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=f1e50]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=f1e51]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=f1e52]: © 2026 Jefferson Nunes. Todos os direitos reservados.
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | for(const momento of ['atrasado','pronto']) test(`B skip - listener ${momento} no retorno da recuperação`,async({page},info)=>{
  3  |  const events:unknown[]=[];await page.exposeFunction('triageEvent',(e:unknown)=>events.push(e));
  4  |  await page.addInitScript(()=>{
  5  |   const original=window.addEventListener;
  6  |   (window as any).__released=false;
  7  |   const pending:(()=>void)[]=[];
  8  |   (window as any).__release=()=>{(window as any).__released=true;for(const run of pending.splice(0))run();};
  9  |   window.addEventListener=function(type:any,listener:any,options:any){
  10 |    if(type==='popstate' && options===true && !(window as any).__released){
  11 |     pending.push(()=>{original.call(this,type,listener,options);(window as any).__captureReady=true;});
  12 |     (window as any).__captureHeld=true;return;
  13 |    }
  14 |    return original.call(this,type,listener,options);
  15 |   } as any;
  16 |   original.call(window,'popstate',(e:PopStateEvent)=>{(window as any).__popSeen=true;(window as any).triageEvent({url:location.href,ready:!!(window as any).__captureReady,trusted:e.isTrusted,stateNull:e.state===null,h1:document.querySelector('h1')?.textContent});});
  17 |  });
  18 |  try {
  19 |   await page.goto('/rota-inexistente#main-content');
  20 |   await page.waitForFunction(()=>{const a=document.querySelector('header a');return !!a && Object.keys(a).some(k=>k.startsWith('__reactFiber')) && history.state!==null;});
  21 |   await page.waitForFunction(()=>(window as any).__captureHeld);
  22 |   if(momento==='pronto')await page.evaluate(()=>(window as any).__release());
  23 |   await page.getByRole('navigation',{name:'Navegação principal'}).getByRole('link',{name:'Projetos',exact:true}).click();
  24 |   await expect(page.locator('h1')).toHaveText('Projetos');await expect(page).toHaveURL(/\/projetos$/);
  25 |   await page.goBack();
  26 |   await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
  27 |   if(momento==='atrasado'){
  28 |    await page.waitForFunction(()=>(window as any).__popSeen);
  29 |    await page.evaluate(()=>(window as any).__release());
  30 |   } else {
> 31 |    await page.waitForFunction(()=>(window as any).__captureHeld);await page.evaluate(()=>(window as any).__release());
     |                                                                             ^ Error: page.evaluate: Execution context was destroyed, most likely because of a navigation
  32 |   }
  33 |   await expect(page.locator('h1')).toHaveText('Página não encontrada');
  34 |  } finally {await info.attach('events',{body:JSON.stringify(events),contentType:'application/json'});}
  35 | });
  36 | 
```