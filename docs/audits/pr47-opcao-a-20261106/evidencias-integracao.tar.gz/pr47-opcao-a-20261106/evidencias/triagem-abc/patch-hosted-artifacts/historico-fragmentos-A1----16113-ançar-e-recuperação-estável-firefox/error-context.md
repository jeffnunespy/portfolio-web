# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico-fragmentos.spec.ts >> A1 - 404 genérica: skip, Voltar/Avançar e recuperação estável
- Location: hosted-triage-tests/historico-fragmentos.spec.ts:244:7

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('h1')
Expected: "Página não encontrada"
Received: "Projetos"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" with timeout 5000ms
  - waiting for locator('h1')
    - waiting for "https://portfolio-82qy5hshv-jeff-0a6e.vercel.app/rota-inexistente" navigation to finish...
    - locator resolved to <h1 id="projects-title">Projetos</h1>
    - unexpected value "Projetos"
    - waiting for "https://portfolio-82qy5hshv-jeff-0a6e.vercel.app/projetos" navigation to finish...
    - navigated to "https://portfolio-82qy5hshv-jeff-0a6e.vercel.app/projetos"
    12 × locator resolved to <h1 id="projects-title">Projetos</h1>
       - unexpected value "Projetos"

```

```yaml
- heading "Projetos" [level=1]
```

# Test source

```ts
  75  | async function pularParaConteudo(page: Page) {
  76  |   await page.keyboard.press("Tab");
  77  |   await expect(page.locator("a.skip-link")).toBeFocused();
  78  |   await page.keyboard.press("Enter");
  79  |   await expect(page.locator("main#main-content")).toBeFocused();
  80  | }
  81  | 
  82  | // Aciona o skip link no HTML pré-renderizado, com os chunks retidos: a entrada
  83  | // de "/" fica sem estado. Devolve a função que libera os chunks.
  84  | async function pularAntesDaHidratacao(page: Page, rota = "/") {
  85  |   let liberar!: () => void;
  86  |   let retidos = 0;
  87  |   const portao = new Promise<void>((resolve) => (liberar = resolve));
  88  |   await page.route("**/_next/static/**/chunks/*.js", async (rota) => {
  89  |     retidos++;
  90  |     await portao;
  91  |     await rota.continue();
  92  |   });
  93  |   await page.goto(rota, { waitUntil: "domcontentloaded" });
  94  |   await pularParaConteudo(page);
  95  |   // Garante que o skip link agiu de fato antes da hidratação.
  96  |   expect(retidos).toBeGreaterThan(0);
  97  |   expect(
  98  |     await page.evaluate(() => {
  99  |       const marca = document.querySelector("header a");
  100 |       return {
  101 |         hidratado: !!marca && Object.keys(marca).some((k) => k.startsWith("__reactFiber")),
  102 |         estado: history.state,
  103 |       };
  104 |     }),
  105 |   ).toEqual({ hidratado: false, estado: null });
  106 |   return liberar;
  107 | }
  108 | 
  109 | // Marca o documento para detectar recarga e coleta erros da página.
  110 | async function vigiar(page: Page) {
  111 |   const erros: string[] = [];
  112 |   page.on("pageerror", (erro) => erros.push(String(erro)));
  113 |   page.on("console", (msg) => {
  114 |     if (msg.type() === "error") erros.push(msg.text());
  115 |   });
  116 |   await page.evaluate(() => {
  117 |     (window as Window & { __documento?: string }).__documento = "inicial";
  118 |   });
  119 |   return async () => {
  120 |     expect(
  121 |       await page.evaluate(() => (window as Window & { __documento?: string }).__documento),
  122 |     ).toBe("inicial");
  123 |     expect(erros).toEqual([]);
  124 |   };
  125 | }
  126 | 
  127 | // Diagnóstico (sem asserção): rota da árvore que o App Router gravou na entrada
  128 | // corrente. É campo interno do Next.js, por isso fica fora das verificações.
  129 | async function anotarArvore(page: Page, momento: string) {
  130 |   const rota = await page.evaluate(() => {
  131 |     type No = [string | [string, string, string], Record<string, No>];
  132 |     let no = (history.state as { __PRIVATE_NEXTJS_INTERNALS_TREE?: { tree?: No } } | null)
  133 |       ?.__PRIVATE_NEXTJS_INTERNALS_TREE?.tree;
  134 |     if (!no) return history.state === null ? "estado nulo" : "sem árvore";
  135 |     const segmentos: string[] = [];
  136 |     while (no) {
  137 |       const segmento = Array.isArray(no[0]) ? no[0][1] : no[0];
  138 |       if (segmento && !segmento.startsWith("__PAGE__")) segmentos.push(segmento);
  139 |       no = no[1]?.children;
  140 |     }
  141 |     return "/" + segmentos.join("/");
  142 |   });
  143 |   test.info().annotations.push({ type: `árvore gravada (${momento})`, description: rota });
  144 | }
  145 | 
  146 | const navegar = (page: Page, rotulo: string) =>
  147 |   page
  148 |     .getByRole("navigation", { name: "Navegação principal" })
  149 |     .getByRole("link", { name: rotulo, exact: true })
  150 |     .click();
  151 | 
  152 | test("F1 - skip link: Voltar e Avançar mantêm URL e conteúdo coerentes", async ({
  153 |   page,
  154 |   browser,
  155 | }) => {
  156 |   await abrir(page, "/");
  157 |   await pularParaConteudo(page);
  158 |   await navegar(page, "Sobre");
  159 |   await esperarRota(page, browser, "/sobre");
  160 | 
  161 |   await page.goBack();
  162 |   await esperarRota(page, browser, "/#main-content");
  163 |   await page.goForward();
  164 |   await esperarRota(page, browser, "/sobre");
  165 |   await page.goBack();
  166 |   await page.goBack();
  167 |   await esperarRota(page, browser, "/");
  168 | });
  169 | 
  170 | // A1: a 404 genérica usa o fallback de documento do Next. A recuperação deve
  171 | // distinguir entradas nulas e não nulas sem recarregar fragmentos na própria
  172 | // 404 nem substituir a F1 nas rotas válidas.
  173 | async function esperar404Generica(page: Page, url: string) {
  174 |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
> 175 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
      |                                    ^ Error: expect(locator).toHaveText(expected) failed
  176 |   await expect(page).toHaveTitle("Página não encontrada | Portfólio");
  177 |   await expect(page.locator("main")).toContainText("A página que você procura não existe");
  178 |   await expect(
  179 |     page.getByRole("navigation", { name: "Navegação principal" }).locator("[aria-current]"),
  180 |   ).toHaveCount(0);
  181 |   await hidratar(page);
  182 | }
  183 | 
  184 | async function observarA1(page: Page) {
  185 |   const documentos: { url: string; status: number }[] = [];
  186 |   const requisicoesRsc: string[] = [];
  187 |   const eventos: unknown[] = [];
  188 |   const erros: string[] = [];
  189 |   page.on("response", (resposta) => {
  190 |     if (resposta.request().resourceType() === "document") {
  191 |       documentos.push({ url: resposta.url(), status: resposta.status() });
  192 |     }
  193 |   });
  194 |   page.on("pageerror", (erro) => erros.push(erro.message));
  195 |   page.on("request", (requisicao) => {
  196 |     if (requisicao.headers()["rsc"]) requisicoesRsc.push(requisicao.url());
  197 |   });
  198 |   // O router às vezes aborta a leitura do corpo da RSC já respondida: conta as
  199 |   // requisições encerradas, com ou sem falha.
  200 |   const rscEncerradas: string[] = [];
  201 |   const encerrarRsc = (requisicao: Request) => {
  202 |     if (requisicao.headers()["rsc"]) rscEncerradas.push(new URL(requisicao.url()).pathname);
  203 |   };
  204 |   page.on("requestfinished", encerrarRsc);
  205 |   page.on("requestfailed", encerrarRsc);
  206 |   await page.exposeFunction("registrarHistoricoA1", (evento: unknown) => eventos.push(evento));
  207 |   await page.addInitScript(() => {
  208 |     const janela = window as unknown as Window & {
  209 |       documentoA1?: string;
  210 |       registrarHistoricoA1: (evento: unknown) => Promise<void>;
  211 |     };
  212 |     janela.documentoA1 = crypto.randomUUID();
  213 |     window.addEventListener("popstate", (evento) => {
  214 |       void janela.registrarHistoricoA1({
  215 |         url: location.href,
  216 |         estado: evento.state,
  217 |         titulo: document.title,
  218 |         h1: document.querySelector("h1")?.textContent,
  219 |       });
  220 |     });
  221 |   });
  222 |   const documento = () =>
  223 |     page.evaluate(() => (window as Window & { documentoA1?: string }).documentoA1);
  224 |   const conferirEstabilidade = async () => {
  225 |     await page.waitForLoadState("networkidle");
  226 |     const quantidade = documentos.length;
  227 |     const quantidadeRsc = requisicoesRsc.length;
  228 |     await page.waitForTimeout(700);
  229 |     expect(documentos).toHaveLength(quantidade);
  230 |     expect(requisicoesRsc).toHaveLength(quantidadeRsc);
  231 |     expect(erros).toEqual([]);
  232 |   };
  233 |   const registrar = async () => {
  234 |     await test.info().attach("historico-a1", {
  235 |       body: JSON.stringify({ documentos, requisicoesRsc, eventos, erros }, null, 2),
  236 |       contentType: "application/json",
  237 |     });
  238 |   };
  239 |   const rscEncerradasDe = (rota: string) => rscEncerradas.filter((p) => p === rota).length;
  240 |   return { documentos, documento, conferirEstabilidade, registrar, rscEncerradasDe };
  241 | }
  242 | 
  243 | for (const entrada of ["skip", "hash direto", "location.hash", "pré-hidratação"] as const) {
  244 |   test(`A1 - 404 genérica: ${entrada}, Voltar/Avançar e recuperação estável`, async ({ page }) => {
  245 |     const observacao = await observarA1(page);
  246 |     const rota = "/rota-inexistente";
  247 |     const url = rota + "#main-content";
  248 |     if (entrada === "pré-hidratação") {
  249 |       const liberar = await pularAntesDaHidratacao(page, rota);
  250 |       liberar();
  251 |       await hidratar(page);
  252 |     } else {
  253 |       await abrir(page, entrada === "hash direto" ? url : rota);
  254 |       if (entrada === "skip") await pularParaConteudo(page);
  255 |       if (entrada === "location.hash") {
  256 |         await page.evaluate(() => {
  257 |           location.hash = "main-content";
  258 |         });
  259 |         await expect(page.locator("main")).toBeFocused();
  260 |       }
  261 |     }
  262 |     await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  263 |     // #45: o estado restaurado pelo Next pertence à 404 confirmada.
  264 |     await expect.poll(() => page.evaluate(() => history.state !== null)).toBe(true);
  265 |     const inicial = await observacao.documento();
  266 |     const entradas = await page.evaluate(() => history.length);
  267 |     await observacao.conferirEstabilidade();
  268 |     expect(observacao.documentos).toHaveLength(1);
  269 |     expect(observacao.documentos[0].status).toBe(404);
  270 | 
  271 |     await page
  272 |       .getByRole("navigation", { name: "Navegação principal" })
  273 |       .getByRole("link", { name: "Sobre", exact: true })
  274 |       .focus();
  275 |     await page.keyboard.press("Enter");
```