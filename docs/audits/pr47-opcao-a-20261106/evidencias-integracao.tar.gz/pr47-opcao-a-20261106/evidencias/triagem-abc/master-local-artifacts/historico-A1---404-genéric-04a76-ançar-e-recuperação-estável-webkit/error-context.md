# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: historico.spec.ts >> A1 - 404 genérica: hash direto, Voltar/Avançar e recuperação estável
- Location: triage-abc-tests/historico.spec.ts:235:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 2
```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - link "Pular para o conteúdo principal" [ref=f1e2]:
    - /url: "#main-content"
  - banner [ref=f1e3]:
    - generic [ref=f1e4]:
      - link "Jefferson Nunes — Início" [ref=f1e5]:
        - /url: /
        - generic [ref=f1e6]: Jefferson Nunes.
      - navigation "Navegação principal" [ref=f1e7]:
        - link "Início" [ref=f1e8]:
          - /url: /
        - link "Projetos" [ref=f1e10]:
          - /url: /projetos
        - link "Roadmap (Plano)" [ref=f1e12]:
          - /url: /roadmap
          - generic [ref=f1e13]: Roadmap
        - link "Sobre" [ref=f1e14]:
          - /url: /sobre
        - link "Currículo (CV)" [ref=f1e16]:
          - /url: /curriculo
          - generic [ref=f1e17]: Currículo
  - main [ref=f1e18]:
    - generic [ref=f1e20]:
      - generic [ref=f1e21]:
        - heading "Página não encontrada" [level=1] [ref=f1e22]
        - paragraph [ref=f1e23]: HTTP 404 · Registro inexistente
        - paragraph [ref=f1e24]: A página que você procura não existe ou foi removida.
        - link "Voltar para a página inicial" [active] [ref=f1e25]:
          - /url: /
        - link "Ver todos os projetos" [ref=f1e26]:
          - /url: /projetos
      - generic [ref=f1e27]:
        - generic [ref=f1e28]:
          - term [ref=f1e29]: Acervo publicado
          - definition [ref=f1e30]: 2 fichas
        - generic [ref=f1e31]:
          - term [ref=f1e32]: Escopo planejado
          - definition [ref=f1e33]: 4 entradas
        - generic [ref=f1e34]:
          - term [ref=f1e35]: Destino de retorno
          - definition [ref=f1e36]: Página inicial
  - contentinfo [ref=f1e37]:
    - generic [ref=f1e38]:
      - navigation "Links secundários" [ref=f1e39]:
        - link "Início" [ref=f1e40]:
          - /url: /
        - link "Projetos" [ref=f1e41]:
          - /url: /projetos
        - link "Roadmap" [ref=f1e42]:
          - /url: /roadmap
        - link "Sobre" [ref=f1e43]:
          - /url: /sobre
        - link "Currículo" [ref=f1e44]:
          - /url: /curriculo
      - region [ref=f1e45]:
        - heading "Vamos conversar." [level=2] [ref=f1e46]
        - paragraph [ref=f1e47]: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
        - generic [ref=f1e48]:
          - link "Enviar e-mail" [ref=f1e49]:
            - /url: mailto:jeffnunesxavier@gmail.com
          - link "Falar pelo LinkedIn" [ref=f1e50]:
            - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
          - link "Ver GitHub" [ref=f1e51]:
            - /url: https://github.com/jeffnunespy
      - paragraph [ref=f1e52]: © 2026 Jefferson Nunes. Todos os direitos reservados.
  - alert [ref=f1e53]
```

# Test source

```ts
  195 |   page.on("requestfinished", encerrarRsc);
  196 |   page.on("requestfailed", encerrarRsc);
  197 |   await page.exposeFunction("registrarHistoricoA1", (evento: unknown) => eventos.push(evento));
  198 |   await page.addInitScript(() => {
  199 |     const janela = window as unknown as Window & {
  200 |       documentoA1?: string;
  201 |       registrarHistoricoA1: (evento: unknown) => Promise<void>;
  202 |     };
  203 |     janela.documentoA1 = crypto.randomUUID();
  204 |     window.addEventListener("popstate", (evento) => {
  205 |       void janela.registrarHistoricoA1({
  206 |         url: location.href,
  207 |         estado: evento.state,
  208 |         titulo: document.title,
  209 |         h1: document.querySelector("h1")?.textContent,
  210 |       });
  211 |     });
  212 |   });
  213 |   const documento = () =>
  214 |     page.evaluate(() => (window as Window & { documentoA1?: string }).documentoA1);
  215 |   const conferirEstabilidade = async () => {
  216 |     await page.waitForLoadState("networkidle");
  217 |     const quantidade = documentos.length;
  218 |     const quantidadeRsc = requisicoesRsc.length;
  219 |     await page.waitForTimeout(700);
  220 |     expect(documentos).toHaveLength(quantidade);
  221 |     expect(requisicoesRsc).toHaveLength(quantidadeRsc);
  222 |     expect(erros).toEqual([]);
  223 |   };
  224 |   const registrar = async () => {
  225 |     await test.info().attach("historico-a1", {
  226 |       body: JSON.stringify({ documentos, requisicoesRsc, eventos, erros }, null, 2),
  227 |       contentType: "application/json",
  228 |     });
  229 |   };
  230 |   const rscEncerradasDe = (rota: string) => rscEncerradas.filter((p) => p === rota).length;
  231 |   return { documentos, documento, conferirEstabilidade, registrar, rscEncerradasDe };
  232 | }
  233 | 
  234 | for (const entrada of ["skip", "hash direto", "location.hash", "pré-hidratação"] as const) {
  235 |   test(`A1 - 404 genérica: ${entrada}, Voltar/Avançar e recuperação estável`, async ({ page }) => {
  236 |     const observacao = await observarA1(page);
  237 |     const rota = "/rota-inexistente";
  238 |     const url = rota + "#main-content";
  239 |     if (entrada === "pré-hidratação") {
  240 |       const liberar = await pularAntesDaHidratacao(page, rota);
  241 |       liberar();
  242 |       await hidratar(page);
  243 |     } else {
  244 |       await abrir(page, entrada === "hash direto" ? url : rota);
  245 |       if (entrada === "skip") await pularParaConteudo(page);
  246 |       if (entrada === "location.hash") {
  247 |         await page.evaluate(() => {
  248 |           location.hash = "main-content";
  249 |         });
  250 |         await expect(page.locator("main")).toBeFocused();
  251 |       }
  252 |     }
  253 |     await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  254 |     // #45: o estado restaurado pelo Next pertence à 404 confirmada.
  255 |     await expect.poll(() => page.evaluate(() => history.state !== null)).toBe(true);
  256 |     const inicial = await observacao.documento();
  257 |     const entradas = await page.evaluate(() => history.length);
  258 |     await observacao.conferirEstabilidade();
  259 |     expect(observacao.documentos).toHaveLength(1);
  260 |     expect(observacao.documentos[0].status).toBe(404);
  261 | 
  262 |     await page
  263 |       .getByRole("navigation", { name: "Navegação principal" })
  264 |       .getByRole("link", { name: "Sobre", exact: true })
  265 |       .focus();
  266 |     await page.keyboard.press("Enter");
  267 |     await expect(page.locator("h1")).toHaveText("Sobre");
  268 |     await expect(page).toHaveTitle("Sobre | Portfólio");
  269 |     expect(await observacao.documento()).toBe(inicial);
  270 | 
  271 |     await page.goBack();
  272 |     await esperar404Generica(page, url);
  273 |     expect(await observacao.documento()).not.toBe(inicial);
  274 |     expect(await page.evaluate(() => history.length)).toBe(entradas + 1);
  275 |     expect(observacao.documentos).toHaveLength(2);
  276 |     expect(observacao.documentos[1].status).toBe(404);
  277 |     // A recarga pode restaurar BODY (histórico salvo antes da hidratação) ou
  278 |     // MAIN (abertura do hash), como nos controles nativos da mesma 404.
  279 |     const foco = await page.evaluate(() => ({
  280 |       tag: document.activeElement?.tagName,
  281 |       id: document.activeElement?.id,
  282 |     }));
  283 |     expect([
  284 |       { tag: "MAIN", id: "main-content" },
  285 |       { tag: "BODY", id: "" },
  286 |     ]).toContainEqual(foco);
  287 |     // #45: restaurar a 404 confirmada não pede RSC nem repete o fragmento.
  288 |     const rscAntesDoSkip = observacao.rscEncerradasDe(rota);
  289 |     await pularParaConteudoFocado(page);
  290 |     await page.keyboard.press("Tab");
  291 |     const voltarParaInicio = page.getByRole("link", { name: "Voltar para a página inicial" });
  292 |     await expect(voltarParaInicio).toBeFocused();
  293 |     await observacao.conferirEstabilidade();
  294 |     await expect(voltarParaInicio).toBeFocused();
> 295 |     expect(observacao.rscEncerradasDe(rota)).toBe(rscAntesDoSkip);
      |                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  296 | 
  297 |     await page.goForward();
  298 |     await expect(page).toHaveURL(/\/sobre$/);
  299 |     await expect(page.locator("h1")).toHaveText("Sobre");
  300 |     await page.goBack();
  301 |     await esperar404Generica(page, url);
  302 |     await observacao.conferirEstabilidade();
  303 |     expect(await page.evaluate(() => history.length)).toBe(entradas + 1);
  304 |     const resposta = await page.reload();
  305 |     expect(resposta?.status()).toBe(404);
  306 |     await esperar404Generica(page, url);
  307 |     await navegar(page, "Projetos");
  308 |     await expect(page.locator("h1")).toHaveText("Projetos");
  309 |     await page.goBack();
  310 |     await esperar404Generica(page, url);
  311 |     await observacao.conferirEstabilidade();
  312 |     await observacao.registrar();
  313 |   });
  314 | }
  315 | 
  316 | test("A1 - fragmentos na própria 404 são nativos e não recarregam", async ({ page }) => {
  317 |   const observacao = await observarA1(page);
  318 |   await abrir(page, "/rota-inexistente");
  319 |   const inicial = await observacao.documento();
  320 |   await pularParaConteudo(page);
  321 |   await page.evaluate(() => {
  322 |     location.hash = "outro-fragmento";
  323 |   });
  324 |   await expect(page).toHaveURL(/#outro-fragmento$/);
  325 |   await page.goBack();
  326 |   await esperar404GenericaSemEstado(page, "/rota-inexistente#main-content");
  327 |   await page.goForward();
  328 |   await esperar404GenericaSemEstado(page, "/rota-inexistente#outro-fragmento");
  329 |   await observacao.conferirEstabilidade();
  330 |   expect(await observacao.documento()).toBe(inicial);
  331 |   expect(observacao.documentos).toHaveLength(1);
  332 |   await observacao.registrar();
  333 | });
  334 | 
  335 | // Verifica a UI sem depender do estado opaco que o Next grava ao restaurar.
  336 | async function esperar404GenericaSemEstado(page: Page, url: string) {
  337 |   await expect(page).toHaveURL((u) => u.pathname + u.hash === url);
  338 |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  339 |   await expect(page).toHaveTitle("Página não encontrada | Portfólio");
  340 | }
  341 | 
  342 | test("A1 - 404 sem hash e 404 de projeto preservam URL, conteúdo e HTTP 404", async ({
  343 |   page,
  344 |   browser,
  345 | }) => {
  346 |   for (const rota of ["/rota-inexistente", "/projetos/slug-inexistente"]) {
  347 |     expect((await page.goto(rota))?.status()).toBe(404);
  348 |     await hidratar(page);
  349 |     if (rota.startsWith("/projetos")) await pularParaConteudo(page);
  350 |     const url = rota + (rota.startsWith("/projetos") ? "#main-content" : "");
  351 |     await navegar(page, "Sobre");
  352 |     await esperarRota(page, browser, "/sobre");
  353 |     await page.goBack();
  354 |     await esperarRota(page, browser, url);
  355 |     await page.goForward();
  356 |     await esperarRota(page, browser, "/sobre");
  357 |     await page.goBack();
  358 |     await esperarRota(page, browser, url);
  359 |   }
  360 | });
  361 | 
  362 | test("A1/F4 - Ler descrição nas três superfícies mantém a F1 e o teclado", async ({
  363 |   page,
  364 |   browser,
  365 | }) => {
  366 |   const ficha = "/projetos/plataforma-portfolio";
  367 |   for (const rota of ["/", "/projetos", ficha]) {
  368 |     await abrir(page, rota);
  369 |     const descricao = page.getByRole("link", { name: "Ler descrição" });
  370 |     await descricao.focus();
  371 |     await page.keyboard.press("Enter");
  372 |     await esperarRota(page, browser, ficha + "#contexto");
  373 |     await expect(page.locator("#contexto")).toBeFocused();
  374 |     // A legenda usa <a> nativo: vindo do card, muda de documento por contrato.
  375 |     // O trecho de histórico da F1 começa na ficha, após essa navegação.
  376 |     const conferir = await vigiar(page);
  377 |     await navegar(page, "Sobre");
  378 |     await esperarRota(page, browser, "/sobre");
  379 |     await page.goBack();
  380 |     await esperarRota(page, browser, ficha + "#contexto");
  381 |     await page.goForward();
  382 |     await esperarRota(page, browser, "/sobre");
  383 |     await conferir();
  384 |   }
  385 | });
  386 | 
  387 | test("A1 - Voltar da 404 com Sobre pendente não classifica Sobre como 404", async ({
  388 |   page,
  389 |   browser,
  390 | }) => {
  391 |   let liberarSobre!: () => void;
  392 |   const portao = new Promise<void>((resolve) => (liberarSobre = resolve));
  393 |   let retidas = 0;
  394 |   await page.route(
  395 |     (url) => url.pathname === "/sobre",
```