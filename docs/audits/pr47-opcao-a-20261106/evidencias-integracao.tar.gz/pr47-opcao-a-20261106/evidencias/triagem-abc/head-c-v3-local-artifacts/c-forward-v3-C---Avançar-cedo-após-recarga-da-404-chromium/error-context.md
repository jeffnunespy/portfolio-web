# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: c-forward-v3.spec.ts >> C - Avançar cedo após recarga da 404
- Location: triage-abc-tests/c-forward-v3.spec.ts:2:46

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/rota-inexistente#main-content$/
Received string:  "http://localhost:3101/rota-inexistente"
Timeout: 5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    14 × locator resolved to <html lang="pt-BR" class="AUUrpW_variable">…</html>
       - unexpected value "http://localhost:3101/rota-inexistente"

```

```yaml
- link "Pular para o conteúdo principal":
  - /url: "#main-content"
- banner:
  - link "Jefferson Nunes — Início":
    - /url: /
    - text: Jefferson Nunes
  - navigation "Navegação principal":
    - link "Início":
      - /url: /
    - link "Projetos":
      - /url: /projetos
    - link "Roadmap (Plano)":
      - /url: /roadmap
      - text: Roadmap
    - link "Sobre":
      - /url: /sobre
    - link "Currículo (CV)":
      - /url: /curriculo
      - text: Currículo
- main:
  - heading "Página não encontrada" [level=1]
  - paragraph: HTTP 404 · Registro inexistente
  - paragraph: A página que você procura não existe ou foi removida.
  - link "Voltar para a página inicial":
    - /url: /
  - link "Ver todos os projetos":
    - /url: /projetos
  - term: Acervo publicado
  - definition: 2 fichas
  - term: Escopo planejado
  - definition: 4 entradas
  - term: Destino de retorno
  - definition: Página inicial
- contentinfo:
  - navigation "Links secundários":
    - link "Início":
      - /url: /
    - link "Projetos":
      - /url: /projetos
    - link "Roadmap":
      - /url: /roadmap
    - link "Sobre":
      - /url: /sobre
    - link "Currículo":
      - /url: /curriculo
  - region "Vamos conversar.":
    - heading "Vamos conversar." [level=2]
    - paragraph: Para conversar sobre os projetos ou oportunidades, envie um e-mail ou fale pelo LinkedIn.
    - link "Enviar e-mail":
      - /url: mailto:jeffnunesxavier@gmail.com
    - link "Falar pelo LinkedIn":
      - /url: https://www.linkedin.com/in/jefferson-nunes-7bb309122/
    - link "Ver GitHub":
      - /url: https://github.com/jeffnunespy
  - paragraph: © 2026 Jefferson Nunes. Todos os direitos reservados.
- alert
```

# Test source

```ts
  1   | import {test,expect} from "@playwright/test";
  2   | for (const fase of ['cedo','hidratado']) test(`C - Avançar ${fase} após recarga da 404`, async ({page}) => {
  3   |   let liberar!: () => void;
  4   |   const portao = new Promise<void>((resolve) => (liberar = resolve));
  5   |   let retidas = 0;
  6   |   let arvoreRecebida = false;
  7   |   page.on("requestfinished", (requisicao) => {
  8   |     if (
  9   |       new URL(requisicao.url()).pathname === "/sobre" &&
  10  |       requisicao.headers()["next-router-segment-prefetch"] === "/_tree"
  11  |     ) {
  12  |       arvoreRecebida = true;
  13  |     }
  14  |   });
  15  |   await page.route(
  16  |     (url) => url.pathname === "/sobre",
  17  |     async (rota) => {
  18  |       const requisicao = rota.request();
  19  |       if (
  20  |         requisicao.resourceType() === "document" ||
  21  |         requisicao.headers()["next-router-segment-prefetch"] === "/_tree"
  22  |       ) {
  23  |         return rota.continue();
  24  |       }
  25  |       retidas++;
  26  |       await portao;
  27  |       await rota.continue().catch(() => {});
  28  |     },
  29  |   );
  30  |   await page.goto("/rota-inexistente");
  31  |   await expect.poll(() => arvoreRecebida).toBe(true);
  32  |   await expect.poll(() => retidas).toBeGreaterThan(0);
  33  |   await page
  34  |     .getByRole("navigation", { name: "Navegação principal" })
  35  |     .getByRole("link", { name: "Sobre", exact: true })
  36  |     .click();
  37  |   await page.waitForTimeout(300);
  38  |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  39  |   await page.locator(".skip-link").focus();
  40  |   await page.keyboard.press("Enter");
  41  |   await expect(page.locator("main")).toBeFocused();
  42  |   await page.keyboard.press("Tab");
  43  |   const voltar = page.getByRole("link", { name: "Voltar para a página inicial" });
  44  |   await expect(voltar).toBeFocused();
  45  |   liberar();
  46  |   await page.waitForLoadState("networkidle");
  47  |   await page.waitForTimeout(500);
  48  |   await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
  49  |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  50  |   await expect(voltar).toBeFocused();
  51  |   await page.evaluate(() => sessionStorage.setItem('triageHoldScheduler','1'));
  52  |   await page.goBack();
  53  |   await expect(page).toHaveURL(/\/rota-inexistente$/);
  54  |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  55  |   await page.waitForFunction(() => (window as any).__schedulerHeld === true);
  56  |   expect(await page.evaluate(() => Object.keys(document.querySelector('header a')!).some(k=>k.startsWith('__reactFiber')))).toBe(false);
  57  |   if (fase === 'hidratado') {
  58  |     await page.evaluate(() => (window as any).__releaseScheduler());
  59  |     await page.waitForFunction(() => (window as any).__captureReady);
  60  |     await page.waitForLoadState('networkidle');
  61  |   }
  62  |   const avancar = page.goForward();
  63  |   if (fase === 'cedo') {
  64  |     await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
  65  |     await page.evaluate(() => (window as any).__releaseScheduler());
  66  |   }
  67  |   await avancar;
  68  |   await page.waitForLoadState('networkidle');
> 69  |   await expect(page).toHaveURL(/\/rota-inexistente#main-content$/);
      |                      ^ Error: expect(page).toHaveURL(expected) failed
  70  |   await expect(page.locator("h1")).toHaveText("Página não encontrada");
  71  | });
  72  | 
  73  | test.beforeEach(async ({page})=> {
  74  |  const log:unknown[]=[];(page as any).__log=log;
  75  |  await page.exposeFunction('triageEvent',(e:unknown)=>log.push(e));
  76  |  await page.addInitScript(()=>{
  77  |  const queued: (()=>void)[] = [];
  78  |  (window as any).__releaseScheduler=()=>{sessionStorage.removeItem('triageHoldScheduler');for(const run of queued.splice(0)) run();};
  79  |  const OriginalChannel=window.MessageChannel;
  80  |  window.MessageChannel=class extends OriginalChannel {
  81  |   constructor(){super();const post=this.port2.postMessage.bind(this.port2);
  82  |    this.port2.postMessage=((...args:any[])=>{
  83  |     if(sessionStorage.getItem('triageHoldScheduler')){
  84  |       (window as any).__schedulerHeld=true;
  85  |       (window as any).triageEvent({kind:'scheduler-held',t:performance.now(),url:location.href,stack:new Error().stack});
  86  |       queued.push(()=>post(...args as [any]));return;
  87  |     }
  88  |     return post(...args as [any]);
  89  |    }) as any;
  90  |   }
  91  |  };
  92  | 
  93  |  const original=window.addEventListener;
  94  |  window.addEventListener=function(type:any,listener:any,options:any){
  95  |  const res=original.call(this,type,listener,options);
  96  |  if(type==='popstate' && options===true) {(window as any).__captureReady=true;(window as any).triageEvent({kind:'capture-ready',t:performance.now(),url:location.href});}
  97  |  return res;} as any;
  98  |  const snap=(kind:string,e?:any)=>(window as any).triageEvent({kind,t:performance.now(),url:location.href,stateNull:history.state===null,ready:!!(window as any).__captureReady,h1:document.querySelector('h1')?.textContent,trusted:e?.isTrusted});
  99  |  for(const kind of ['popstate','hashchange','pageshow','pagehide']) original.call(window,kind,(e:Event)=>snap(kind,e));
  100 |  for(const method of ['pushState','replaceState'] as const){
  101 |  const originalHistory=History.prototype[method];
  102 |  History.prototype[method]=function(...args:any[]){const result=originalHistory.apply(this,args as any);snap(method);return result;};
  103 |  }
  104 |  });
  105 | });
  106 | test.afterEach(async({page},info)=>{await info.attach('events',{body:JSON.stringify((page as any).__log),contentType:'application/json'});});
  107 | 
```