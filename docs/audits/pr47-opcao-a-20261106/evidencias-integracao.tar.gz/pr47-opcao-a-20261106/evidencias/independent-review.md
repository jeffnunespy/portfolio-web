# Revisão independente — PR #47, opção A

Autoria: agente `/root/review_option_a`, com auditorias estreitas de constituição/conteúdo e acessibilidade delegadas a `/root/review_option_a/audit_constitution` e `/root/review_option_a/audit_a11y`. Data: 2026-11-06. Revisão do diff `0d69203e5553578c252714baed7d1e924ba685dd..3736977a1dad19f2a4635fac8c789fe1f0c2ccf4` e dos relatórios abaixo; nenhum teste novo executado pelo revisor nesta consolidação.

## Parecer

**NO-GO.** A separação da limitação da History API está justificada; o bloqueio atual decorre de falhas e lacunas de homologação de requisitos de histórico/A1, independentemente dessa limitação. O CI verde não supera as falhas dirigidas observadas no mesmo candidato. Não há conclusão de regressão causada pelo patch para cada falha: sua causa permanece em investigação.

## Evidências conferidas

| Motor | Local dirigido | Preview dirigido | Teclado no Preview |
| --- | --- | --- | --- |
| Chromium | 26/27 aprovados | 23/27 aprovados | 1/1 aprovado |
| Firefox | 27/27 aprovados | 27/27 aprovados | 1/1 aprovado |
| WebKit | 27/27 aprovados | 25/27 aprovados | 1/1 aprovado |

Fontes: `results-head.json`, `preview-results.json`, `keyboard-results.json`. Sem skips ou retries nos relatórios conferidos. A repetição isolada `results-head-repeat.json` passou 3/3, sem alteração, mas não apaga a falha original.

O registro recuperado `recovered-hosted-evidence.json` comprova execução hospedada anterior e preserva seus resultados favoráveis e falhas. Identidade histórica: deployment `dpl_EnWNDNXMztJLLTJwSWC4vntPfq2d`, SHA `3736977a1dad19f2a4635fac8c789fe1f0c2ccf4`, BUILD_ID `i_qv7YR4GKIqrXi-ZwgRu`. A identidade atual foi reconferida pelo agente principal. Fonte histórica: saídas reais de ferramentas, não afirmações do agente. Screenshots/traces e payloads completos antigos continuam indisponíveis.

## Bloqueios de aceite e observações

1. **Homologação A1 pendente no WebKit:** no Preview, o caso `skip` chegou a `Projetos` quando a recuperação exigia `Página não encontrada` (`historico-fragmentos.spec.ts:166`, chamada em `:310`). O caso `location.hash` não atingiu o estado não nulo exigido pelo teste do candidato (`:255`). São falhas efetivas de asserção; ainda não há evidência suficiente para classificá-las como defeito do produto, limitação preexistente ou interferência da homologação. Não substituir esses resultados por sondas históricas mais estreitas.
2. **Orientação por fragmentos pendente no Chromium hospedado:** quatro casos falharam na asserção `:target`, retornando `undefined` em vez de `contexto`, `projects-title` ou `limitacoes` (`historico-fragmentos.spec.ts:46`). R05 documenta a ressalva em Firefox/WebKit; isso não autoriza estendê-la ao Chromium hospedado sem diagnóstico equivalente. Não afrouxar a asserção para obter aprovação.
3. **Instabilidade local ainda sem causa:** o teste novo de cancelamento de Sobre suspenso falhou após Avançar, recebendo `/rota-inexistente` sem hash em vez de `/rota-inexistente#main-content` (`foco-404-latencia.spec.ts:119`). Três repetições isoladas passaram; isso demonstra intermitência/condição de execução, sem provar que a falha original era inválida. Manter log e trace originais. Não há base para declarar toda a validação local aprovada.
4. **Leitor de tela real:** não foi validado. A issue #45 menciona avaliação com leitor de tela; registrar a situação e o critério de encerramento expressamente. Axe, teclado automatizado e revisão semântica não equivalem a essa validação. T055 permanece aberta. O NO-GO acima já se sustenta nas falhas de homologação, sem depender de ampliar esse escopo.

## Pendência independente: History API durante suspensão

`diagnostic-comparison.json` registra comparação equivalente do head e da master integral: em cada versão, os três controles sem alteração de History API passaram e as seis variantes `pushState`/`replaceState` falharam. No Chromium ocorre nova navegação de documento para a query; em Firefox/WebKit há navegação para Sobre antes da liberação das respostas retidas. A reprodução compara condições controladas e confirma preexistência na master avaliada; não identifica sozinha uma causa definitiva no Next/React nem garante todos os ambientes e temporizações.

Essa falha não deve ser usada para exigir um contorno no PR #47. Preservar a reprodução como teste independente com asserções reais, fora dos gates obrigatórios; manter as falhas visíveis e registrar condições, impacto, próxima investigação e responsável quando definido. Não usar `skip`, `test.fail`, mocks de sucesso ou remoção de asserções para convertê-la em aprovação.

## Critérios para reavaliar GO

- Explicar e resolver, ou demonstrar por comparação equivalente a classificação independente de cada falha hospedada A1/fragmentos, preservando os requisitos aprovados.
- Concluir foco sob latência, progressão por teclado, cancelamento F1 e recuperação A1 nos três motores no artefato de identidade conferida; preservar PROD-001 sem JavaScript.
- Resolver a classificação da falha intermitente do teste novo, sem descartar a execução original nem promovê-la a aprovação por maioria de repetições.
- Manter o CI `quality` verde associado ao head e ao commit sintético avaliado; não declarar asserções hospedadas aprovadas pelo CI local.
- Registrar o estado da avaliação com leitor real e da T055, sem aprovação humana artificial.

Sem violação constitucional ou alteração de conteúdo público demonstrada no diff. Nenhuma recomendação de mudar dependências, contornar a History API ou modificar a correção original. Esta revisão não autoriza merge, deploy ou publicação remota.
