# Issue #45 — sessão humana assistida

## Registro inicial — histórico

Estado: sessão iniciada. Proprietário confirmou “confirmado e aberto” após orientação
para ativar o Orca e abrir a 404 no Firefox. Primeiro cenário de teclado orientado;
resultado ainda aguardado. Nenhum cenário aprovado.

Ambiente detectado pelo agente: Firefox 159.0, Orca 46.1, Speech Dispatcher
instalados; DISPLAY :0, X11 e barramento de sessão presentes. Configuração
`toolkit-accessibility=false`. Sandbox impediu acesso ao áudio e escrita dconf;
Verificação direta pelo agente permanece limitada. O proprietário confirmou
Orca e abertura da página; anúncios específicos ainda não relatados.
Não foram solicitadas ou registradas credenciais.

Artefato previsto: https://portfolio-82qy5hshv-jeff-0a6e.vercel.app
Identidade histórica do roteiro: SHA 3736977a1dad19f2a4635fac8c789fe1f0c2ccf4,
BUILD_ID i_qv7YR4GKIqrXi-ZwgRu. Não reconfirmada nesta sessão humana.

| Cenário | Resultado relatado pelo proprietário |
| --- | --- |
| Skip visível → Enter na 404 | Pendente |
| Tab progride ao link de retorno | Pendente |
| Foco após carregamento assíncrono, incluindo query | Pendente |
| Sobre pendente → skip/Tab → permanência na 404 | Pendente |
| Recuperação por Enter, Voltar/Avançar, Tab/Shift+Tab | Pendente |
| Anúncios e orientação com leitor real | Pendente |

Pessoa, data da execução, SO, leitor/navegador efetivamente usados e latência:
a registrar com o proprietário. Sem resultados de automação nesta tabela.

Decisão de risco: ainda não solicitada após execução; nenhum aceite presumido.
B/skip mantém classificação encerrada: causa original indeterminada; regressão
do PR #47 não demonstrada. Riscos A/C e dependência do App Router permanecem
conforme roteiro. T055 e R05 abertas. Sem commit, push, merge ou deploy.

## Continuação — avaliações humanas B e C, 2026-11-06

Registro efetuado em 2026-11-06 15:59:22 UTC. Esta seção atualiza o estado
histórico acima. Escopo limitado às duas avaliações humanas restantes; os
resultados anteriores de teclado, histórico, foco visual e automação Firefox
sob latência de 389 a 600 ms foram informados pelo proprietário e não foram
reexecutados como verificações nesta continuação.

### B — Firefox com Orca: inconclusivo, dispensado pelo proprietário

O proprietário informou “não precisa desse teste”. Não houve relato dos anúncios
do Orca para skip link, conteúdo principal ou link de retorno nesta continuação.
Avaliação não realizada; nenhuma aprovação ou reprovação registrada. A dispensa
não comprova o comportamento com leitor de tela real.

### C — observação humana sob retenção de RSC: aprovado no cenário observado

Identidade consultada em modo somente leitura na API da Vercel:

- Preview: https://portfolio-82qy5hshv-jeff-0a6e.vercel.app.
- Deployment: `dpl_EnWNDNXMztJLLTJwSWC4vntPfq2d`, `READY`, Preview.
- PR #47, commit `3736977a1dad19f2a4635fac8c789fe1f0c2ccf4`.
- Firefox visível 153.0, fornecido pela instalação existente do Playwright,
  em Linux/X11, com contexto separado do navegador original do proprietário.
- Acesso autorizado preexistente da Vercel reutilizado apenas em memória;
  nenhuma credencial exibida ou persistida pelo procedimento, e nenhuma
  autorização nova criada.

Preparação assistida: a interceptação foi instalada antes do carregamento da
404. A navegação para `/sobre`, a ativação do skip e o avanço ao link de retorno
foram preparados pelo controlador para disponibilizar a cena de observação sem
espera entre essas ações. Isso não foi registrado como novo teste humano de
teclado nem como aprovação visual automática.

A retenção ocorreu após obter respostas reais do Preview e antes de entregá-las
ao Firefox. Não se trata de medição da latência natural do servidor. As duas
respostas de `/sobre` tinham HTTP 200 e `Content-Type: text/x-component`:

| Resposta | Retenção até a entrega pelo controlador |
| --- | --- |
| RSC da navegação, sem cabeçalho de segmento | 28.139 ms |
| RSC de pré-carregamento, segmento `/sobre/__PAGE__` | 28.253 ms |

Observações efetivamente relatadas pelo proprietário na tentativa válida:

1. Antes da liberação, título “Página não encontrada” e contorno de foco no
   link “Voltar para a página inicial”.
2. Após a liberação, orientado a observar sem mouse ou teclado, relatou que
   continuou a mesma coisa e não houve mudança. Não relatou salto de foco.

A leitura instrumental posterior à entrega também registrou
`/rota-inexistente#main-content`, o título da 404 e o link de retorno como
elemento ativo. Essa leitura corrobora o registro, mas não substitui a observação
humana anterior e posterior, que fundamenta o resultado C.

Tentativas anteriores com ausência de RSC retida, saída da 404 ou clique antes
de observar o foco após a liberação ficaram inconclusivas. Em particular, a
tentativa com retenção de aproximadamente 154 segundos não foi aprovada: o
proprietário informou que clicou na página e não observou o intervalo anterior
ao clique. O resultado aprovado acima pertence à repetição com retenção de
28.139 ms da RSC de navegação.

### Pendências e limites separados

- **Issue #45 / T113:** C concluído para o cenário descrito; B permanece sem
  evidência humana com Orca, dispensado pelo proprietário. Não houve decisão
  de encerramento da issue, alteração de tarefas ou aceite geral de risco.
- **T055 geral:** permanece aberta; esta sessão não avalia as demais rotas,
  zoom, aparelho físico ou demais inspeções gerais de publicação.
- **R05:** permanece aberta e independente; não foi reavaliada nem aceita
  por este resultado.

Somente este registro documental foi atualizado no repositório. Nenhum código
do produto ou dependência foi alterado. Não foram executados commit, push,
merge, deploy ou publicação de mensagens no GitHub.
